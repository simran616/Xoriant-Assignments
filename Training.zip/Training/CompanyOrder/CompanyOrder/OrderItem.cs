﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyOrder
{
    class OrderItem
    {
        public int Qty { get; set; }
        public Item Item { get; set; }
        public double GetAmount()
        {
            //double totalAmount = Item.Price * this.Qty;
            //double discountedAmount = totalAmount * discount / 100;
            return Item.Price * this.Qty;
        }
    }
}
