﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyOrder
{
    class Order
    {
        private List<OrderItem> items = new List<OrderItem>();
        public Customer Customer { get; set; }

        public int OrderID { get; set; }

        public void AddOrderItem(OrderItem item)
        {
            this.items.Add(item);
        }
        public IEnumerable<OrderItem> GetOrderItems()
        {
            return this.items;
        }
        public double GetOrderValue()
        {
            double totalAmount = 0;
            foreach (var item in items )
            {
                totalAmount += item.GetAmount();
            }
            return totalAmount;
        }
    }
}
