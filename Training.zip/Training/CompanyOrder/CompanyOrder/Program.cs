﻿using System;

namespace CompanyOrder
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Create Items
            Item item1 = new Item() { PId = "A001", ItemName = "IPhone11", Price = 10000 };
            Item item2 = new Item() { PId = "A002", ItemName = "IPhone12", Price = 20000 };
            Item item3 = new Item() { PId = "A003", ItemName = "IPhone12 Pro", Price = 30000 };
            Item item4 = new Item() { PId = "A004", ItemName = "IPhone13", Price = 40000 };
            Item item5 = new Item() { PId = "A005", ItemName = "IPhone13 Pro", Price = 50000 };

            //2.Create Company
            Company company = new Company() { CompanyName = "APPLE" };

            //3.Add Items to company
            company.AddItem(item1);

            //4.Create Customer
            Customer customer1 = new Customer() { CustomerName = "Raj" };
            Customer customer2 = new Customer() { CustomerName = "Shraddha" };
            Customer customer3 = new Customer() { CustomerName = "Laxmi" };
            Customer customer4 = new Customer() { CustomerName = "Tarun" };
            RegisteredCustomer customer5 = new RegisteredCustomer() { CustomerName = "Vardaan" };


            //5.Add Customer to Company
            company.AddCustomer(customer1);
            company.AddCustomer(customer2);
            company.AddCustomer(customer3);
            company.AddCustomer(customer4);
            company.AddCustomer(customer5);

            //6.Add Company to Customer
            customer1.Company = company;
            customer2.Company = company;
            customer3.Company = company;
            customer4.Company = company;
            customer5.Company = company;

            //7.Create Order
            Order order1 = new Order() { OrderID = 1 };
            Order order2 = new Order() { OrderID = 2 };
            Order order3 = new Order() { OrderID = 3 };
            Order order4 = new Order() { OrderID = 4 };
            Order order5 = new Order() { OrderID = 5 };
            Order order6 = new Order() { OrderID = 6 };

            //8.Add Order to Customer
            customer1.AddOrder(order1);
            customer2.AddOrder(order2);
            customer3.AddOrder(order3);
            customer4.AddOrder(order4);
            customer5.AddOrder(order5); //reg customer
            customer5.AddOrder(order6); //reg customer

            //9.Add Customer to Order
            order1.Customer = customer1;
            order2.Customer = customer2;
            order3.Customer = customer3;
            order4.Customer = customer4;
            order5.Customer = customer5; //reg customer
            order6.Customer = customer5; //reg customer

            //10' Add OrderItems
            OrderItem orderItem1 = new OrderItem() { Qty = 1 };
            OrderItem orderItem2 = new OrderItem() { Qty = 2 };
            OrderItem orderItem3 = new OrderItem() { Qty = 1 };
            OrderItem orderItem4 = new OrderItem() { Qty = 1 };
            OrderItem orderItem5 = new OrderItem() { Qty = 3 };
            OrderItem orderItem6 = new OrderItem() { Qty = 2 };
            OrderItem orderItem7 = new OrderItem() { Qty = 2 };
            OrderItem orderItem8 = new OrderItem() { Qty = 1 };


            //11' Add Item to orderItem
            orderItem1.Item = item1;
            orderItem2.Item = item2;
            orderItem3.Item = item3;
            orderItem4.Item = item4;
            orderItem5.Item = item5;
            orderItem6.Item = item1;
            orderItem7.Item = item3;
            orderItem8.Item = item5;

            //12' Add OrderItems to Order

            order1.AddOrderItem(orderItem1);
            order1.AddOrderItem(orderItem2);

            order2.AddOrderItem(orderItem3);
            order2.AddOrderItem(orderItem4);

            order3.AddOrderItem(orderItem5);

            order4.AddOrderItem(orderItem6);
            order4.AddOrderItem(orderItem7);

            order5.AddOrderItem(orderItem6);

            order6.AddOrderItem(orderItem1);
            //order6.AddOrderItem(orderItem2);
            //order6.AddOrderItem(orderItem8);

            //Display Company 
            DisplayCompanyDetails(company);
        }

        private static void DisplayCompanyDetails(Company company)
        {
            DrawLine("*", 40);
            Console.Write($"\tCOMPANY NAME: {company.CompanyName}");
            DrawLine("*", 40);
            Console.WriteLine($"\nTotal Customers: {company.GetTotalCustomers()}");
            Console.WriteLine($"Total Sales Value: {company.GetTotalSales()}");

            Console.Write($"\nCustomer Order Details: ");
            DrawLine("=", 25);
            foreach (var customers in company.GetCustomers())
            {
                //int discount = customers.Discount;
                Console.WriteLine($"Customer Name: {customers.CustomerName}");
                //Console.WriteLine("Order Details:");
                foreach (var orders in customers.GetOrders())
                {
                    Console.WriteLine($"Order ID:{orders.OrderID}");
                    //DrawLine("-", 30);
                    Console.Write($"\nPId\tItem Name\tQty\t Price\t Amount");
                    
                    DrawLine("-", 50);
                    foreach (var items in orders.GetOrderItems())
                    {
                        Console.Write($"\n{items.Item.PId}\t{items.Item.ItemName}\t{items.Qty}\tRs{items.Item.Price}\t Rs{items.GetAmount()}");
                    }
                    DrawLine(".", 50);
                    Console.Write($"Total Amount:\t\t\t\t Rs{orders.GetOrderValue()} ");
                    DrawLine(".", 50);
                    Console.WriteLine("");
                }
                
            }


        }

        private static void DrawLine(string pattern, int noPattern)
        {
            Console.WriteLine();
            for (int i = 1; i <= noPattern; i++)
            {
                Console.Write("{0}", pattern);
            }
            Console.WriteLine();
        }
    }
}
