﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyOrder
{
    class Customer
    {
        public int Discount { get; set; } = 0;
        private List<Order> orders = new List<Order>();
        public Company Company { get; set; }
        public string CustomerName { get; set; }
        public void AddOrder(Order order) => this.orders.Add(order);
        public IEnumerable<Order> GetOrders()
        {
            return this.orders;
        }

    }
}
