﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyOrder
{
    class Company
    {
        private List<Item> items = new List<Item>();

        private List<Customer> customers = new List<Customer>();

        public string CompanyName { get; set; }
        public void AddItem(Item item) => this.items.Add(item);
        public IEnumerable<Item> GetItems()
        {
            return this.items;
        }

        public void AddCustomer(Customer customer) => this.customers.Add(customer);
        public IEnumerable<Customer> GetCustomers()
        {
            return this.customers;
        }
        public int GetTotalCustomers()
        {
            int total = 0;
            foreach(var customers in this.GetCustomers())
            {
                total++;
            }
            return total;
        }
        public double GetTotalSales()
        {
            double total = 0;
            foreach (var customers in this.GetCustomers())
            {
                foreach(var orders in customers.GetOrders())
                {
                    total += orders.GetOrderValue();
                }
            }
            return total;
        }
    }
}
