﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyOrder
{
    class RegisteredCustomer : Customer
    {
        public new int Discount { get; set; } = 10;
    }
}
