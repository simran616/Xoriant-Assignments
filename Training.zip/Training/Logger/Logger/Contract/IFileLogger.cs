﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CommonLayer.Enum.LogTypeEnum;

namespace CommonLayer.Contract
{
    public interface IFileLogger
    {
        /// <summary>
        /// log content to file
        /// </summary>
        /// <param name="content">content</param>
        /// <param name="logType">type of log i.e. system generated or custom</param>
        /// <returns></returns>
        bool LogContent(string content, LogType logType);

        /// <summary>
        /// log content to file
        /// </summary>
        /// <param name="content">content</param>
        /// <param name="logType">type of log i.e. system generated or custom & error number if any</param>
        /// <returns></returns>
        bool LogContent(string content, LogType logType, int errorNumber);

        /// <summary>
        /// Write lof to file
        /// </summary>
        /// <param name="content"></param>
        /// <param name="logType"></param>
        /// <param name="errorNumber"></param>
        void WriteLogToFile(string content, LogType logType, int errorNumber = 0);
    }
}