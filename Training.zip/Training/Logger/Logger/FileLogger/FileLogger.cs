﻿using CommonLayer.Contract;
using CommonLayer.Enum;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CommonLayer.Enum.LogTypeEnum;

namespace CommonLayer.FileLogger
{
    public class FileLogger : IFileLogger
    {
        private string filePath = string.Empty;
        private string filename = string.Empty;

        /// <summary>
        /// This class is for logging exceptions to the text file
        /// </summary>
        public FileLogger()
        {
            this.filename = @"\Log_" + DateTime.Now.Date.ToString("MMM dd, yyyy") + ".txt";
            this.filePath = GetDefaultPath();
        }

        public FileLogger(string path) : base()
        {
            this.filePath = path + filename;
            if (path == string.Empty)
            {
                this.filePath = GetDefaultPath();
            }
        }

        private string GetDefaultPath()
        {
            return Environment.CurrentDirectory.Split("Debug")[0] + @"\SopOnLogs\" + filename;
        }

        /// <summary>
        ///Log content and Logtype
        /// </summary>
        /// <param name="content"></param>
        /// <param name="logType">Its a enum </param>
        /// <returns></returns>
        public bool LogContent(string content, LogType logType)
        {
            WriteLogToFile(content, logType);
            return true;
        }

        /// <summary>
        ///log content, type and error number
        /// </summary>
        /// <param name="content"></param>
        /// <param name="logType"></param>
        /// <param name="errorNumber"></param>
        /// <returns></returns>
        public bool LogContent(string content, LogType logType, int errorNumber)
        {
            return true;
        }

        /// <summary>
        /// Write log to text file
        /// </summary>
        /// <param name="content"></param>
        /// <param name="logType"></param>
        public void WriteLogToFile(string content, LogType logType)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(this.filePath, true))
                {
                    sw.WriteLine("-------------------------------------------------------------");
                    sw.WriteLine($"Date: {DateTime.Now},Log Type:{logType}, Content:{content}");
                    sw.WriteLine("--------------------------------------------------------------");
                }
            }
            catch (DirectoryNotFoundException ex)
            {
                LogContent(ex.StackTrace, LogType.SystemException);
            }
        }

        /// <summary>
        /// write log to text file
        /// </summary>
        /// <param name="content"></param>
        /// <param name="logType"></param>
        /// <param name="errorNumber"></param>
        public void WriteLogToFile(string content, LogType logType, int errorNumber)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(this.filePath, true))
                {
                    sw.WriteLine("-------------------------------------------------------------");
                    sw.WriteLine($"Date: {DateTime.Now}, Error Number:{errorNumber}, Log Type:{logType}, Content:{content}");
                    sw.WriteLine("--------------------------------------------------------------");
                }
            }
            catch (DirectoryNotFoundException ex)
            {
                LogContent(ex.StackTrace, LogType.SystemException);
            }
        }
    }
}