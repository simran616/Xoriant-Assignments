﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Enum
{
    public class LogTypeEnum
    {
        /// <summary>
        /// Enum used in Logging for type identification
        /// </summary>
        public enum LogType
        {
            SystemException,
            CustomException
        }
    }
}