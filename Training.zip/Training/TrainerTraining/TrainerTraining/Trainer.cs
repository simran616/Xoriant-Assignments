﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainerTraining
{
    class Trainer
    {
        public string TrainerName { get; set; }

        private List<Trainee> trainees = new List<Trainee>();
        public Training Training { get; set; }

        public void AddTrainee(Trainee trainee)
        {
            this.trainees.Add(trainee);
        }
        public IEnumerable<Trainee> GetTrainees()
        {
            return this.trainees;
        }

    }
}
