﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainerTraining
{
    class Training
    {
        public string TrainingName { get; set; }
        public Trainer Trainer { get; set; }

        private List<Trainee> trainee = new List<Trainee>();
        public Course Course { get; set; }
        public void AddTrainee(Trainee trainee)
        {
            this.trainee.Add(trainee);
        }
        public IEnumerable<Trainee> GetTrainees()
        {
            return this.trainee;
        }
        public int GetTrainingDuration()
        {
            return Course.GetCourseDuration();
        }
    }
}
