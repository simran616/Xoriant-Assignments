﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainerTraining
{
    class Course
    {
        private List<Module> modules = new List<Module>();
        private List<Training> trainings = new List<Training>();
        public string CourseName { get; set; }
        public Technology Technology { get; set; }
        public void AddModule(Module module)
        {
            this.modules.Add(module);
        }
        public IEnumerable<Module> GetModules()
        {
            return this.modules;
        }
        public void AddTrainings(Training training)
        {
            this.trainings.Add(training);
        }
        public IEnumerable<Training> GetTrainings()
        {
            return this.trainings;
        }
        public int GetCourseDuration()
        {
            int total = 0;
            foreach (var module in this.modules)
            {
                total += module.GetModuleDuration();
            }
            return total;
        }
    }
}
