﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainerTraining
{
    class Unit
    {
        public string UnitName { get; set; }
        public int UnitDuration { get; set; }
        private List<Topic> topic = new List<Topic>();
        public void AddTopic(Topic topic)
        {
            this.topic.Add(topic);
        }
        public IEnumerable<Topic> GetTopics()
        {
            return this.topic;
        }
    }
}
