﻿using System;

namespace TrainerTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Create Topic
            Topic topic1 = new Topic() { TopicName = "If" };
            Topic topic2 = new Topic() { TopicName = "While" };
            Topic topic3 = new Topic() { TopicName = "For" };
            Topic topic4 = new Topic() { TopicName = "Foreach" };
            Topic topic5 = new Topic() { TopicName = "Switch" };
            Topic topic6 = new Topic() { TopicName = "Table" };
            Topic topic7 = new Topic() { TopicName = "p" };
            Topic topic8 = new Topic() { TopicName = "try in JS" };
            Topic topic9 = new Topic() { TopicName = "Create object in JS" };
            Topic topic10 = new Topic() { TopicName = "while in JS" };

            //2.Create Unit
            Unit unit1 = new Unit { UnitName = "Control Structure", UnitDuration = 30 };
            Unit unit2 = new Unit { UnitName = "Looping", UnitDuration = 40 };
            Unit unit3 = new Unit { UnitName = "HTML Tags", UnitDuration = 30 };
            Unit unit4 = new Unit { UnitName = "JavaScript Basics", UnitDuration = 20 };
            Unit unit5 = new Unit { UnitName = "JavaScript OO", UnitDuration = 40 };
            Unit unit6 = new Unit { UnitName = "Advance JS Functions", UnitDuration = 50 };

            //3.Add topic to units
            unit1.AddTopic(topic1);
            unit2.AddTopic(topic2);
            unit2.AddTopic(topic3);
            unit2.AddTopic(topic4);
            unit2.AddTopic(topic5);
            unit3.AddTopic(topic6);
            unit3.AddTopic(topic7);
            unit4.AddTopic(topic8);
            unit5.AddTopic(topic9);
            unit6.AddTopic(topic10);

            //4.Create module
            Module module1 = new Module() { ModuleName = "C# Basic" };
            Module module2 = new Module() { ModuleName = "HTML Fundamental" };
            Module module3 = new Module() { ModuleName = "JavaScript Fundamental" };


            //5.Add unit to module
            module1.AddUnit(unit1);
            module1.AddUnit(unit2);
            module2.AddUnit(unit3);
            module3.AddUnit(unit4);
            module3.AddUnit(unit5);
            module3.AddUnit(unit6);

            //6.Create course
            Course course = new Course() { CourseName = "C# Programming" };

            //7.Add module to course
            course.AddModule(module1);
            course.AddModule(module2);
            course.AddModule(module3);

            //8.Create technology
            Technology technology = new Technology() { TechnologyName = ".Net Core" };

            //9.Add technology to course
            course.Technology = technology;

            //10.add course to technology
            technology.AddCourse(course);

            //11.create training
            Training training = new Training() { TrainingName = "STEER- Batch13" };

            //12.add course to training
            training.Course = course;

            //13.add training to course
            course.AddTrainings(training);

            //14.create trainer
            Trainer trainer = new Trainer() { TrainerName = "Shashi" };

            //15.add trainer to training
            training.Trainer = trainer;

            //16.add training to trainer
            trainer.Training = training;

            //17.create trainee
            Trainee trainee1 = new Trainee() { TraineeName = "Simran" };
            Trainee trainee2 = new Trainee() { TraineeName = "Vaibhavi" };
            Trainee trainee3 = new Trainee() { TraineeName = "Mohini" };
            Trainee trainee4 = new Trainee() { TraineeName = "Yashashwi" };
            Trainee trainee5 = new Trainee() { TraineeName = "Dhivya" };

            //18.add trainer to trainee
            trainee1.Trainer = trainer;
            trainee2.Trainer = trainer;
            trainee3.Trainer = trainer;
            trainee4.Trainer = trainer;
            trainee5.Trainer = trainer;

            //19.add trainee to trainer
            trainer.AddTrainee(trainee1);
            trainer.AddTrainee(trainee2);
            trainer.AddTrainee(trainee3);
            trainer.AddTrainee(trainee4);
            trainer.AddTrainee(trainee5);

            //20.add trainee to training
            training.AddTrainee(trainee1);
            training.AddTrainee(trainee2);
            training.AddTrainee(trainee3);
            training.AddTrainee(trainee4);
            training.AddTrainee(trainee5);

            //21.add training to trainee
            trainee1.Training = training;
            trainee2.Training = training;
            trainee3.Training = training;
            trainee4.Training = training;
            trainee5.Training = training;

            //22.Display Training
            DisplayTrainingInfo(training);
        }
            
        private static void DisplayTrainingInfo(Training training)
        {
            DrawLine("*", 40);
            Console.Write("\tTRAINING INFORMATION");
            DrawLine("*", 40);
            Console.WriteLine($"\nTraining Name: {training.TrainingName}\t\t Duration: {training.GetTrainingDuration()}");
            Console.WriteLine($"Technology Used: {training.Course.Technology.TechnologyName}");
            Console.WriteLine($"Trainer: {training.Trainer.TrainerName}");
            Console.Write($"Trainees List: " );
        
            foreach(var trainee in training.GetTrainees())
            {
                Console.Write($"{trainee.TraineeName}  ");
            }
            Console.WriteLine();
            DrawLine("-", 35);
            Console.Write("\tCOURSE INFORMATION");
            DrawLine("-", 35);
            Console.Write($"\nCourse Name: {training.Course.CourseName}\t\t Duration: {training.Course.GetCourseDuration()}");
            DrawLine("=", 60);
            
            foreach(var module in training.Course.GetModules())
            {
                Console.Write($"\n\tModule Name: {module.ModuleName}\t Module Duration: {module.GetModuleDuration()}");
                DrawLine("-", 50);
                foreach(var unit in module.GetUnits())
                {
                    Console.WriteLine($"\t\tUnit Name: {unit.UnitName}\t Duration:{unit.UnitDuration}");
                    foreach(var topic in unit.GetTopics())
                    {
                        Console.WriteLine($"\t\t\tTopic Name: {topic.TopicName}");
                    }
                }
            }
          
        
        }
        
        private static void DrawLine(string pattern, int noPattern)
        {
            Console.WriteLine();
            for(int i = 1; i <= noPattern; i++)
            {
                Console.Write("{0}",pattern);
            }
            Console.WriteLine();
        }
        
    }
}
