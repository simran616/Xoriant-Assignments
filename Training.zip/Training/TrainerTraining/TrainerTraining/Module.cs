﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainerTraining
{
    class Module
    {
        public string ModuleName { get; set; }
        private List<Unit> units = new List<Unit>();
        public void AddUnit(Unit unit)
        {
            this.units.Add(unit);
        }
        public IEnumerable<Unit> GetUnits()
        {
            return this.units;
        }
        public int GetModuleDuration()
        {
            int total = 0;
            foreach(var unit in units)
            {
                total += unit.UnitDuration;
            }
            return total;
        }
    }
}
