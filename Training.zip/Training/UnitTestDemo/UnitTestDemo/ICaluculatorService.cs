﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestDemo
{
    public interface ICaluculatorService
    {
        int Add(int no1, int no2);
        int Division(int no1, int no2);
        int Substraction(int no1, int no2);
        int Multiplication(int no1, int no2);
    }
}
