﻿using CommonLayer.Models;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class UserRepositoryDBImpl : IUserRepository
    {
        string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_TicketTrackingSys;Integrated Security=True";

        public bool CheckUserRole(string empId)
        {
            bool isRole = false;
            string sqlSt = @"SELECT EID
                            FROM dbo.Employee
                            WHERE EID= " + empId + ";";
            
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Employee employee = new Employee();
                        //product.PId = Convert.ToInt32(reader["pid"]);
                        isRole = true;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return isRole;
        }
    }
}
