﻿using BusinessLayer.Contract;
using DataAccessLayer;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class UserManager : IUserMAnager
    {
        private IUserRepository userRepo = null;
        public UserManager()
        {
            
            this.userRepo = new UserRepositoryDBImpl();

        }
        public bool CheckUserRole(string empID)
        {
            return this.userRepo.CheckUserRole(empID);
        }
    }
}
