﻿using BusinessLayer;
using BusinessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrackingSystem
{
    public class UserMenu
    {
        public void Menu()
        {
            //User Menu
            IUserMAnager userManager = new UserManager();
        }
        public bool CheckUserRole()
        {
            IUserMAnager userManager = new UserManager();
            bool isRole = false;
            Console.WriteLine("Please enter the Employee ID:");
            string empId = Console.ReadLine();

            isRole = userManager.CheckUserRole(empId);

            return isRole;

        }
    }
}
