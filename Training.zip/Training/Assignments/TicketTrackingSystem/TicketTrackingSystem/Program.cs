﻿using System;

namespace TicketTrackingSystem
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("\t==================================");
            Console.WriteLine("\tWELCOME TO TICKET TRACKING SYSTEM");
            Console.WriteLine("\t==================================");


            //check whether employee is an admin or a user
            var role = new UserMenu().CheckUserRole();
            if (role)
            {
                //admin menu
            }
            else
            {
                //user menu
            }
        }
        
    }
}
