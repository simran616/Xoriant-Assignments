﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Models
{
    public class Employee
    {
        public int EID { get; set; }
        public string EmployeeName { get; set; }
        public DateTime HireDate { get; set; }
        public string Department { get; set; }
        public List<Ticket> Tickets { get; set; }
    }
}
