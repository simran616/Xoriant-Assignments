﻿using BusinessLayer;
using BusinessLayer.Contract;
using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrackingSystem
{
    public class AdminMenu
    {
        
        public void Menu()
        {
            IAdminManager adminManager = new AdminManager();
            int choice;
            do
            {
                Console.WriteLine("1.Display All Tickets");
                Console.WriteLine("2.Update Tickets");
                Console.WriteLine("3.Go Back to Login Page");
                

                Console.Write("\nEnter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Clear();
                    ShowTickets(adminManager);
                    Console.WriteLine();

                }
                else if (choice == 2)
                {
                    Console.Clear();
                    UpdateTicket(adminManager);
                    Console.WriteLine();

                }
                else if (choice == 3)
                {
                    Console.Clear();
                    new UserMenu().CheckUserRole();
                    Console.WriteLine();
                }

                else
                {
                    Console.WriteLine("Invalid Option");
                }
            } while (choice != 3);
        }
        private static void ShowTickets(IAdminManager adminManager)
        {
            Console.WriteLine("Ticket-ID\tLogged By\tRaised Date\tSeverity\tTicket Description \tResolved By\tResolution \tResolved Date\tStatus");
            Console.WriteLine("=================================================================================================================================================\n");
            try
            {
                foreach (var ticket in adminManager.GetTickets())
                {
                    if (ticket != null)
                    {
                        Console.WriteLine($"{ticket.TicketID}\t{ticket.Logged_By}\t{ticket.RaiseTicketDate}\t{ticket.Severity}\t{ticket.TicketDescription} \t{ticket.Resolved_By}\t{ticket.Resolution}\t{ticket.ResolveDate}\t{ticket.Status}");
                        Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

                    }
                    else
                    {
                        Console.WriteLine("There are no Tickets to Display");

                        Console.WriteLine("---------------------------------------------------------------------------------------------------------------------");
                    }
                }
                   
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static void UpdateTicket(IAdminManager adminManager)
        {
            try
            {
                Console.WriteLine("\n\tDisplaying Open tickets");
                Console.WriteLine("\t=============================");
                ShowOpenTickets(adminManager);

                Ticket ticket = new Ticket();
                Console.WriteLine("Enter the Ticket ID:");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Resolved by");
                string ResolvedBy = Console.ReadLine();
                Console.WriteLine("Enter Resolution Description:");
                string Resolution = Console.ReadLine();

                Ticket ticket1 = new Ticket();
                if (adminManager.UpdateTicketdetails(ticket1))
                {
                    Console.WriteLine("Ticket Updated !!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Not Updated");
                Console.WriteLine(e.Message);
            }

        }

        private static void ShowOpenTickets(IAdminManager adminManager)
        {
            Console.WriteLine("Ticket ID\tLogged By\tRaised Date \tSeverity\tTicket Description\tResolved By\tResolution\tResolved Date\tStatus");
            try
            {
                foreach (var ticket in adminManager.GetOpenTickets())
                {
                    if (ticket != null)
                    {
                        Console.WriteLine($"{ticket.TicketID}\t{ticket.Logged_By}\t{ticket.RaiseTicketDate}\t{ticket.Severity}\t{ticket.TicketDescription}\t{ticket.Resolved_By}\t{ticket.Resolution}\t{ticket.ResolveDate}\t{ticket.Status}");
                        Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");

                    }
                    else
                    {
                        Console.WriteLine("There are no tickets to Update");

                    }

                }
                    
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
