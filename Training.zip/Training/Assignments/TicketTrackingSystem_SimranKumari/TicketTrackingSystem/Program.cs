﻿using System;

namespace TicketTrackingSystem
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("\t==================================");
            Console.WriteLine("\tWELCOME TO TICKET TRACKING SYSTEM");
            Console.WriteLine("\t==================================\n\n");

            
            //check whether employee is an admin or a user
           
            var role = new UserMenu().CheckUserRole();
            if (role)
            {
                //admin menu
                Console.Clear();
                Console.WriteLine("\nWelcome to the Admin Menu");
                Console.WriteLine("====================\n");

                new AdminMenu().Menu();

            }
            else
            {
                //user menu
                Console.Clear();
                Console.WriteLine("\tWelcome to the User Menu");
                Console.WriteLine("\t======================\n");

                new UserMenu().Menu();
            }
        }
    }
}
