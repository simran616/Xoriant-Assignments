﻿using BusinessLayer;
using BusinessLayer.Contract;
using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrackingSystem
{
    public class UserMenu
    {
        public void Menu()
        {
            //User Menu

            IUserManager userManager = new UserManager();
            int choice;
            do
            {
                Console.WriteLine("1.Raise a Ticket");
                Console.WriteLine("2.My Tickets");
                Console.WriteLine("3.Close a Ticket");
                Console.WriteLine("4.Cancel a Ticket");
                Console.WriteLine("5.Go Back to Login Page");

                Console.Write("\nEnter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Clear();
                    LogNewTicket(userManager);
                    Console.WriteLine();

                }
                else if (choice == 2)
                {
                    Console.Clear();
                    DisplayTickets(userManager);
                    Console.WriteLine();

                }
                else if (choice == 3)
                {
                    Console.Clear();
                    UpdtateTicketId(userManager, choice);
                    Console.WriteLine();

                }
                else if (choice == 4)
                {
                    Console.Clear();
                    UpdtateTicketId(userManager, choice);
                    Console.WriteLine();

                }
                else if (choice == 5)
                {
                    Console.Clear();
                    CheckUserRole();
                    Console.WriteLine();

                }
                else
                {
                    Console.WriteLine("Invalid Option");
                } 
            } while (choice != 5);

        }

        private void DisplayTickets(IUserManager userManager)
        {
            Console.WriteLine("Please enter the Ticket ID:");
            int ticketId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"\nTicket-ID\tRaised Date\tSeverity\tDescription\tStatus");
            Console.WriteLine("----------------------------------------------------------");
            var ticketDetails = userManager.GetTicketDetails(ticketId);
            if (ticketDetails != null)
            {
                var result = $"{ticketDetails.TicketID}\t{ticketDetails.RaiseTicketDate}\t{ticketDetails.Severity}\t{ticketDetails.TicketDescription}\t{ticketDetails.Status}";
                Console.WriteLine(result);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Ticket not Found\n");
            }
        }

        private void UpdtateTicketId(IUserManager userManager, int type)
        {
            Ticket ticket = new Ticket();
            Console.WriteLine("Enter Ticket ID:");
            ticket.TicketID = Convert.ToInt32(Console.ReadLine());

            try
            {
                var isUpdated = userManager.UpdateTicket(ticket,type);
                if (isUpdated)
                {
                    if(type==3)
                        Console.WriteLine($"\nTicket with Ticket ID: {ticket.TicketID} is Closed\n");
                    else
                        Console.WriteLine($"\nTicket with Ticket ID: {ticket.TicketID} is Cancelled\n");

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void LogNewTicket(IUserManager userManager)
        {

            Ticket ticket = new Ticket();

            Console.WriteLine("Enter Employee ID:");
            ticket.EmployeeID = Console.ReadLine();

            Console.WriteLine("Enter Severity:");
            ticket.Severity = Console.ReadLine();

            Console.WriteLine("Enter Ticket Description:");
            ticket.TicketDescription = Console.ReadLine();


            try
            {
                var isInserted = userManager.LogTicket(ticket);
                if (isInserted)
                {
                    Console.WriteLine($"\nTicket is raised with Ticket ID: {ticket.TicketID}\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public bool CheckUserRole()
        {
            Console.WriteLine("\t-------------");
            Console.WriteLine("\tLogin Page");
            Console.WriteLine("\t-------------");

            IUserManager userManager = new UserManager();
            bool isRole = false;
            try
            {
                
                Console.WriteLine("Please enter the Employee ID:");
                string empId = Console.ReadLine();

                isRole = userManager.CheckUserRole(empId);

               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return isRole;
        }
    }
}
