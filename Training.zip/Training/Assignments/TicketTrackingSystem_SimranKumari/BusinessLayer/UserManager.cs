﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using DataAccessLayer.Contract;
using DataAccessLayer.DBImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class UserManager : IUserManager
    {
        private IUserRepository userRepo = null;
        public UserManager()
        {

            this.userRepo = new UserRepositoryDBImpl();

        }
        public bool CheckUserRole(string empID)
        {
            return this.userRepo.CheckUserRole(empID);
        }

        public Ticket GetTicketDetails(int ticketId)
        {
            return this.userRepo.GetTicketDetails(ticketId);
        }

        public bool LogTicket(Ticket ticket)
        {
            return this.userRepo.LogTicket(ticket);
        }

        public bool UpdateTicket(Ticket ticket, int type)
        {
            return this.userRepo.UpdateTicket(ticket,type);
        }
    }
}
