﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IUserManager
    {
        public bool CheckUserRole(string empID);
        public bool LogTicket(Ticket ticket);
        public bool UpdateTicket(Ticket ticket, int type);
        public Ticket GetTicketDetails(int ticketId);
    }
}
