﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IAdminManager
    {
       public IEnumerable<Ticket> GetTickets();
       public IEnumerable<Ticket> GetOpenTickets();
       public bool UpdateTicketdetails(Ticket ticket1);
    }
}
