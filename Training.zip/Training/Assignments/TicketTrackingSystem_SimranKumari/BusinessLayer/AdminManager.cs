﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using DataAccessLayer.Contract;
using DataAccessLayer.DBImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class AdminManager : IAdminManager
    {
        private IAdminRepository adminRepo = null;
        public AdminManager()
        {

            this.adminRepo = new AdminRepositoryDBImpl();

        }

        public IEnumerable<Ticket> GetOpenTickets()
        {
            return this.adminRepo.GetOpenTickets();
        }

        public IEnumerable<Ticket> GetTickets()
        {
            return this.adminRepo.GetTickets();
        }

        public bool UpdateTicketdetails(Ticket ticket1)
        {
            return this.adminRepo.UpdateTicketdetails(ticket1);
        }
    }
}
