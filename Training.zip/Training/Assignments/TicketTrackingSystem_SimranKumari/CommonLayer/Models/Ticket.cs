﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Models
{
    public class Ticket
    {
        public int TicketID { get; set; }
        public string Logged_By { get; set; }
        public DateTime RaiseTicketDate { get; set; }
        public string Severity { get; set; }
        public string TicketDescription { get; set; }
        public string Resolved_By { get; set; }
        public string Resolution { get; set; }
        public DateTime ResolveDate { get; set; }
        public string Status { get; set; }
        public Employee Employee { get; set; }
        public string EmployeeID { get; set; }
    }
}
