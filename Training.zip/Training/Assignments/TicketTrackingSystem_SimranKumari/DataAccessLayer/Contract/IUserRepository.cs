﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Contract
{
    public interface IUserRepository
    {
        public bool CheckUserRole(string empId);

        public bool LogTicket(Ticket ticket);
        public bool UpdateTicket(Ticket ticket, int type);
        public Ticket GetTicketDetails(int ticketId);
    }
}
