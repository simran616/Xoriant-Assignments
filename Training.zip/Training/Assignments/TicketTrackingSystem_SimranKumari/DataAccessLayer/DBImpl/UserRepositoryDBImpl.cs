﻿using CommonLayer.Models;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBImpl
{
    public class UserRepositoryDBImpl : IUserRepository
    {
        string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_TicketTrackingSys;Integrated Security=True";

        public bool CheckUserRole(string empId)
        {
            bool isRole = false;
            string sqlSt = @"SELECT EID
                            FROM dbo.Employee
                            WHERE Dept='DEVOPS' AND EID='" + empId+"';";

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Employee employee = new Employee();
                        employee.EID = reader["EID"].ToString();
                        isRole = true;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return isRole;
        }

        public Ticket GetTicketDetails(int ticketId)
        {
            //List<Ticket> tickets = new List<Ticket>();
            //SqlConnection sqlConnection = null;
            string sqlSt = "SP_GetTicketsByEmployeeID";
            Ticket ticket = null;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    //if we are using stotred proc, we have to mention in command.text
                    command.CommandType = CommandType.StoredProcedure;

                    //passing the parameters to the stored proc
                    SqlParameter ticket_Id = command.Parameters.Add("@TicketID", SqlDbType.Int);
                    ticket_Id.Value = ticketId;

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        ticket = new Ticket();
                        ticket.TicketID = Convert.ToInt32(reader["Ticket_ID"]);
                        ticket.RaiseTicketDate = Convert.ToDateTime(reader["Raised_Date"]);
                        ticket.Severity = reader["Severity"].ToString();
                        ticket.TicketDescription = reader["Ticket_Desc"].ToString();
                        ticket.Status = reader["Status"].ToString();

                        //customers.Add(customer);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return ticket;
        }

        public bool LogTicket(Ticket ticket)
        {
            bool isInserted = false;
            string sqlSt = "SP_LogTicket";

            try
            {

                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    //passing the parameters to the stored proc
                    SqlParameter loggedBy = command.Parameters.Add("@LoggedBy", SqlDbType.VarChar);
                    loggedBy.Value = ticket.EmployeeID;
                    loggedBy.Direction = System.Data.ParameterDirection.Input;

                    SqlParameter severity = command.Parameters.Add("@Severity", SqlDbType.VarChar);
                    severity.Value = ticket.Severity;
                    severity.Direction = System.Data.ParameterDirection.Input;

                    SqlParameter ticketDescription = command.Parameters.Add("@Ticket_Desc", SqlDbType.VarChar);
                    ticketDescription.Value = ticket.TicketDescription;
                    ticketDescription.Direction = System.Data.ParameterDirection.Input;


                    SqlParameter ticketId = command.Parameters.Add("@TicketId", SqlDbType.Int);
                    ticketId.Direction = ParameterDirection.Output;

                    command.CommandType = CommandType.StoredProcedure;
                    int noOfRecords = command.ExecuteNonQuery();
                    if (noOfRecords > 0)
                    {
                        var newTicketId = Convert.ToInt32(command.Parameters["@TicketId"].Value);
                        ticket.TicketID = newTicketId;
                        isInserted = true;
                    }


                }

            }
            catch (Exception)
            {
                
                throw;
            }
            return isInserted;
        }

        public bool UpdateTicket(Ticket ticket, int type)
        {
            bool isInserted = false;
            string sqlSt = "SP_UpdateTicket";

            try
            {

                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    //passing the parameters to the stored proc
                   
                    SqlParameter ticketId = command.Parameters.Add("@TicketId", SqlDbType.Int);
                    ticketId.Value = ticket.TicketID;
                    ticketId.Direction = System.Data.ParameterDirection.Input;

                    SqlParameter action = command.Parameters.Add("@Type", SqlDbType.Int);
                    action.Value = type;
                    action.Direction = System.Data.ParameterDirection.Input;

                    command.CommandType = CommandType.StoredProcedure;
                    int noOfRecords = command.ExecuteNonQuery();
                    if (noOfRecords > 0)
                    {
                        isInserted = true;
                    }


                }

            }
            catch (Exception)
            {

                throw;
            }
            return isInserted;
        }
    }
}
