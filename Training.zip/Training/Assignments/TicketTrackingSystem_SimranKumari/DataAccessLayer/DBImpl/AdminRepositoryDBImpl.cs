﻿using CommonLayer.Models;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBImpl
{
    public class AdminRepositoryDBImpl : IAdminRepository
    {
        string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_TicketTrackingSys;Integrated Security=True";

        public IEnumerable<Ticket> GetTickets()
        {
            List<Ticket> tickets = new List<Ticket>();
            string sp = "SP_GetTickets";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sp, connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataReader readData = command.ExecuteReader();
                    while (readData.Read())
                    {
                        Ticket ticket = new Ticket();
                        ticket.TicketID = Convert.ToInt32(readData["Ticket_ID"]);
                        ticket.Logged_By = (readData["Logged_By"]).ToString();
                        ticket.RaiseTicketDate = Convert.ToDateTime(readData["Raised_Date"]);
                        ticket.Severity = (readData["Severity"]).ToString();
                        ticket.TicketDescription = (readData["Ticket_Desc"]).ToString();
                        ticket.Resolved_By = (readData["Resolved_By"]).ToString();
                        ticket.Resolution = (readData["Resolution"]).ToString();
                        ticket.ResolveDate = Convert.ToDateTime(readData["Resolved_Date"]);
                        ticket.Status = (readData["Status"]).ToString();
                        tickets.Add(ticket);
                    }

                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return tickets;
        }

        public IEnumerable<Ticket> GetOpenTickets()
        {
            List<Ticket> tickets = new List<Ticket>();
            string sp = "SP_ShowOpenTickets";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sp, connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataReader readData = command.ExecuteReader();
                    while (readData.Read())
                    {
                        Ticket ticket = new Ticket();
                        ticket.TicketID = Convert.ToInt32(readData["Ticket_ID"]);
                        ticket.Logged_By = (readData["Logged_By"]).ToString();
                        ticket.RaiseTicketDate = Convert.ToDateTime(readData["Raised_Date"]);
                        ticket.Severity = (readData["Severity"]).ToString();
                        ticket.TicketDescription = (readData["Ticket_Desc"]).ToString();
                        ticket.Resolved_By = (readData["Resolved_By"]).ToString();
                        ticket.Resolution = (readData["Resolution"]).ToString();
                        ticket.ResolveDate = Convert.ToDateTime(readData["Resolved_Date"]);
                        ticket.Status = (readData["Status"]).ToString();
                        tickets.Add(ticket);
                    }

                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return tickets;
        }
        
        public bool UpdateTicketdetails(Ticket ticket)
        {
            bool isUpdated = false;
            string spName = "SP_UpdateTicketByAdmin";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(spName, connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TicketID", ticket.TicketID);
                    command.Parameters.AddWithValue("@Resolved_By", ticket.Resolved_By);
                    command.Parameters.AddWithValue("@Resolution", ticket.Resolution);
                    command.Parameters.AddWithValue("@Status", ticket.Status);

                    int recordUpdated = command.ExecuteNonQuery();
                    if (recordUpdated > 0)
                    {
                        isUpdated = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                //throw;
            }
            return isUpdated;
        }
    }
}
