USE [db_TicketTrackingSys]
GO

/****** Object:  Table [dbo].[Tickets]    Script Date: 5/13/2022 8:20:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Tickets](
	[Ticket_ID] [int] IDENTITY(1,1) NOT NULL,
	[Logged_By] [varchar](50) NOT NULL,
	[Raised_Date] [date] NOT NULL,
	[Severity] [varchar](50) NOT NULL,
	[Ticket_Desc] [varchar](100) NOT NULL,
	[Resolved_By] [varchar](50) NULL,
	[Resolution] [varchar](100) NULL,
	[Resolved_Date] [datetime] NULL,
	[Status] [varchar](20) NOT NULL,
 CONSTRAINT [PK_Tickets] PRIMARY KEY CLUSTERED 
(
	[Ticket_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Tickets]  WITH CHECK ADD  CONSTRAINT [FK_Logged_By] FOREIGN KEY([Logged_By])
REFERENCES [dbo].[Employee] ([EID])
GO

ALTER TABLE [dbo].[Tickets] CHECK CONSTRAINT [FK_Logged_By]
GO

