﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EFDataLayer.Models
{
    public partial class Offer
    {
        public int OfferId { get; set; }
        public string OfferType { get; set; }
        public int Discount { get; set; }
        public DateTime OfferTime { get; set; }
        public string Remark { get; set; }
        public int BankId { get; set; }

        public virtual Bank Bank { get; set; }
    }
}
