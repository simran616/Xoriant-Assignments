﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EFDataLayer.Models
{
    public partial class Bank
    {
        public Bank()
        {
            Offers = new HashSet<Offer>();
        }

        public int BankId { get; set; }
        public string BankName { get; set; }
        public string City { get; set; }
        public string Ifsc { get; set; }
        public bool IsDeleted { get; set; }

        public virtual ICollection<Offer> Offers { get; set; }
    }
}
