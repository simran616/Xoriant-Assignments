﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public sealed class SealedDemo
    {
        public void Display()
        {
            Console.WriteLine("Sealed class calling...");
        }
    }
    
    public static class SealedDemoExtensions
    {
        public static void DisplayExtension(this SealedDemo obj)
        {
            Console.WriteLine("Extension method calling...");
        }
    }
    
   
}
