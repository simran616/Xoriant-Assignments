﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class MultiplicationTable
    {
        public void Multiplication()
        {
            Console.WriteLine("Please enter the limit");
            int limit = Convert.ToInt32(Console.ReadLine());
            for (int rows = 1; rows <= 10; rows++)
            {
                for (int column = 1; column <= limit; column++)
                {
                    Console.Write("{0}X{1}={2}\t", column, rows, (column * rows));
                }
                Console.WriteLine("\n");
            }
        }
    }
}
