﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class ListDemo
    {
        public void ListExample()
        {
            //Add elements in the List

            List<int> numbers = new List<int>();
            numbers.Add(10);
            numbers.Add(20);
            numbers.Add(30);

            // Display list elements
            Console.WriteLine("Elements in the List:");
            DisplayNumbers(numbers);
            Console.WriteLine("***********************\n");

            //Count - Returns the total number of elements exists in the List<T>
            int count = numbers.Count();
            Console.WriteLine($"Total number of elements in the List: {count}");
            Console.WriteLine("***********************\n");

            //Contains - 	Checks whether the specified element exists or not in a List<T>.
            Console.WriteLine("Checking whether specific element exist or not in a List");
            Console.WriteLine("---------------------------------------------------------\n");
            Console.WriteLine("Number to be searched: 20");
            bool result = numbers.Contains(20);
            if (result == true)
            {
                Console.WriteLine("Number (20) present in the list");
            }
            else
            {
                Console.WriteLine("Number (20) is not present in the List");
            }
            Console.WriteLine("*************************\n");

            //Insert - Inserts an element at the specified index in a List<T>.
            Console.WriteLine("Inserting (40) at index 3 ");
            numbers.Insert(3, 40);
            Console.WriteLine("Elements in the List after inserting new element:");
            DisplayNumbers(numbers);
            Console.WriteLine("***********************\n");

            //Remove - Removes the first occurrence of the specified element.
            Console.WriteLine("Removing the element (20) from the List");
            bool result1 = numbers.Remove(20);
            if (result1 == true)
            {
                Console.WriteLine("Element (20) removed");
            }
            else
            {
                Console.WriteLine("Sorry, element (20) is not present in the List");
            }
            Console.WriteLine("After Removing - Total elements in the List are:");
            DisplayNumbers(numbers);
            Console.WriteLine("**********************************\n");


        }

        private void DisplayNumbers(List<int> numbers)
        {
            //Foreach - Iterates through a List<T>.
            foreach (var num in numbers)
            {
                Console.WriteLine($"{num}");
            }
        }
    }
}
