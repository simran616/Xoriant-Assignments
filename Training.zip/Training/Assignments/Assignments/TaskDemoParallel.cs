﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemoParallel
    {
        public void Main()
        {
            var course = new List<string> { "Angular", "React", "SQL Server", "ASP.NET", "MVC" };

            //foreach (var item in course)
            //{
            //    Console.WriteLine(item);
            //}

            Parallel.ForEach(course, item => Console.WriteLine($"{item}"));
        }
    }
}
