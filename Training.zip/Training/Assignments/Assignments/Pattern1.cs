﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class Pattern1
    {
        public void DisplayPattern1()
        {
           
            for (int i = 1; i <= 5; i++)
            {
                for(int j=1;j<=i;j++)
                {
                    Console.Write("*");
                }
                Console.Write("\n");
            }
        }
        

    }
}
