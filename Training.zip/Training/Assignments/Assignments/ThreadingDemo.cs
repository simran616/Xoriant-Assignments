﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class ThreadingDemo
    {
        public void Main()
        {
            Thread thread1 = Thread.CurrentThread;
            Show();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Main thread {i},Thread Name {thread1.Name}");
                Thread.Sleep(1000);
            }
        }

        public void Show()
        {
            Thread thread1 = Thread.CurrentThread;
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Show Thread {i}");
                Thread.Sleep(2000);
            }
        }
    }
}
