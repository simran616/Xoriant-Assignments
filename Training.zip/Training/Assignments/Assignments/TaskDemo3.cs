﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemo3
    {
        public void Main()
        {
            Console.WriteLine("Main Started");
            var task1 = Task.Factory.StartNew(() => PrintData(1, 2000));
            var task2 = Task.Factory.StartNew(() => PrintData(2, 5000));
            var task3 = Task.Factory.StartNew(() => PrintData(3, 1000));
            Console.WriteLine("End of Main");
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }

        private void PrintData(int taskNo, int sleepTime)
        {
            Console.WriteLine($"Task {taskNo} started");
            Thread.Sleep(sleepTime);
            Console.WriteLine($"Task {taskNo} completed");
        }
    }
}
