﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class NumberToWords
    {
        public void NumberToWordsCoversion()
        {
            string words;

            ReadNumbers(out words);
            ConvertToWords(ref words);
        }

        private void ReadNumbers(out string words)
        {
            Console.WriteLine("Enter numeric value: ");
            words = Console.ReadLine();
        }

        private void ConvertToWords(ref string words)
        {
            Numbers num;

            foreach(var item in words.ToCharArray())
            {
                Enum.TryParse(item.ToString(), out num);
                Console.Write("{0}\t",num);
            }

        }

        
    }
}
