﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemo4
    {
        public void Main()
        {
            Console.WriteLine("Main Started");
            var task1 = Task.Factory.StartNew(() => Test(1, 2000)).ContinueWith((prevTask) => GenerateReport(1, 1000));
            var task2 = Task.Factory.StartNew(() => Test(2, 5000)).ContinueWith((prevTask) => GenerateReport(2, 2000));
            var task3 = Task.Factory.StartNew(() => Test(3, 1000)).ContinueWith((prevTask) => GenerateReport(3, 500));
            Console.WriteLine("End of Main");
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }

        private void GenerateReport(int taskNo, int sleepTime)
        {
            Console.WriteLine($"GenerateReport {taskNo} started");
            Thread.Sleep(sleepTime);
            Console.WriteLine($"GenerateReport {taskNo} completed");

        }

        private void Test(int taskNo, int sleepTime)
        {
            Console.WriteLine($"Test {taskNo} started");
            Thread.Sleep(sleepTime);
            Console.WriteLine($"Test {taskNo} completed");
        }
    }
}
