﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class DictionaryDemo
    {
        public void DictionaryExample()
        {
            
            Dictionary<int, string> userDetails = new Dictionary<int, string>();
            GetUsers(userDetails);
            Display(userDetails);

        }
        private void GetUsers(Dictionary<int, string> userDetails)
        {
            bool res;
            int id; string name;
            Console.WriteLine("Enter User Details\n");
            Console.Write("Enter User Id: ");
            res = int.TryParse(Console.ReadLine(), out id);
            Console.Write("Enter User Name: ");
            name = Console.ReadLine();
            userDetails.Add(id, name);

        }
        private void Display(Dictionary<int, string> userDetails)
        {

            foreach (var item in userDetails)
            {
                Console.WriteLine($"\nUser Id:{item.Key}, User Name:{item.Value}");
            }
        }
    }
}
