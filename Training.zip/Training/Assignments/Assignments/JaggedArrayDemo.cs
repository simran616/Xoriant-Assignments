﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class JaggedArrayDemo
    {
        public void DisplayJaggedArray()
        {
            int[][] jaggedArray = new int[3][];
            
            jaggedArray[0] = new int[2] { 1, 2 };
            jaggedArray[1] = new int[4] { 3, 6, 9, 12 };
            jaggedArray[2] = new int[3] { 4, 8, 12 };
            
            for (int i = 0; i < jaggedArray.Length; i++)
            {
                System.Console.Write("Element at ({0}) position: ", i + 1);
                for (int j = 0; j < jaggedArray[i].Length; j++)
                {
                    System.Console.Write($"{jaggedArray[i][j]} ");
                }
                System.Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
