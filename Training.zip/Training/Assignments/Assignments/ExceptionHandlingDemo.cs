﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class ExceptionHandlingDemo
    {
        public void Show()
        {
            try
            {
                Console.WriteLine("");
                int no1 = 10, no2 = 20;
                int result = no1 / no2;
                Console.WriteLine($"Dividing number1: {no1} by number2: {no2}. Result= {result}");

                //below code is written to exit the program before the execution of finally block
                Environment.Exit(0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("finally block called...");
            }
        }
    }
    
}
