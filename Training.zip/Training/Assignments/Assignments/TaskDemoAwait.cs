﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemoAwait
    {
        public void Main()
        {
            TaskDemoAwait taskDemo = new TaskDemoAwait();
            var sum = taskDemo.PrintSum(10);
            Console.WriteLine($"Sum is: {sum.Result}");
        }

        public async Task<int> PrintSum(int num)
        {
            int sum = 0;
            return await Task.Run(() =>
            {
                for (int i = 1; i <= 10; i++)
                {
                    sum += i;
                }
                return sum;
            });
        }
    }
}
