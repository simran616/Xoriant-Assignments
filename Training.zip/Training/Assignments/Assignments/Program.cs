﻿using System;
using Assignments.MessageService;

namespace Assignments
{
    class Program
    {
        static void Main(string[] args)
        {
            //Assignment-Day12:
            new TaskDemo1().Main();
            new TaskDemo2().Main();
            new TaskDemo3().Main();
            new TaskDemo4().Main();
            new TaskDemo5().Main();
            new TaskDemoAwait().Main();
            new TaskDemoParallel().Main();

        }
    }
}
