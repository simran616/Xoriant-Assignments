﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class Pattern3
    {
        public void DisplayPattern3()
        {
            int i, j;
            for (i = 1; i <= 5; i++)
            {
                for (j = 1; j <=5; j++)
                {
                    if (j <= 5 - i)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("* ");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
