﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class MultiThreadingDemo
    {
        public void Main()
        {
            Thread thread = Thread.CurrentThread;
            thread.Name = "My Thread";
            Thread thread2 = new Thread(PrintSum);
            Thread thread3 = new Thread(PrintSub);
            thread2.Start();
            thread3.Start();
            thread.Join();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Main thread {i},Thread Name {thread.Name}");
                Thread.Sleep(1000);
            }
        }

        public void Show()
        {
            Thread thread1 = Thread.CurrentThread;
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Show Thread {i}");
                Thread.Sleep(2000);
            }
        }

        public void PrintSum()
        {
            Console.WriteLine("10");
        }

        public void PrintSub()
        {
            Console.WriteLine("20");
        }
    }
}
