﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public class SearchFilesUsingDirectory
    {
        public string path = string.Empty;
        public string fileName = string.Empty;

        public void SearchFiles()
        {
            Console.WriteLine("Enter the path of the file:");
            path = Console.ReadLine();
            Console.WriteLine("Enter the file name:");
            fileName = Console.ReadLine();
            Search(path, fileName);
        }
        public void Search(string path, string fileName)
        {
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(path);
                var fileInfo = directoryInfo.GetFiles();
                foreach (var file in fileInfo)
                {
                    if (string.Equals(file.Name, fileName, StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine($"File found at: {file.FullName}");
                    }
                    else
                    {
                        Console.WriteLine($"Sorry, No File with name- {fileName} found at the given path");
                    }
                }
                var directory = directoryInfo.GetDirectories();
                foreach (var dir in directory)
                {

                    path = dir.FullName;
                    Search(path, fileName);
                }
            }
            catch (Exception)
            {

                Console.WriteLine("File does not exist at the given path.");
            }
        }

    }
}
