﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemo1
    {
        public void Main()
        {
            Task task = new Task(DrawRoad);
            task.Start();
            Console.WriteLine("End of Main");
        }

        private void DrawRoad()
        {
            Console.WriteLine("DrawRoad is called");
            Thread.Sleep(1000);
        }
    }
}
