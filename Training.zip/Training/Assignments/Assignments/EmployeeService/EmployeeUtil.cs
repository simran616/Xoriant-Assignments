﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments.EmployeeService
{
    public delegate bool IsPromotable(Employee emp);
    class EmployeeUtil
    {
        public IEnumerable<Employee> GetPromotionList(List<Employee> employees, IsPromotable canPromote)
        {
            List<Employee> promotedEmployees = new List<Employee>();
            foreach (var emp in employees)
            {
                if (canPromote(emp))
                    promotedEmployees.Add(emp);
            }
            return promotedEmployees;
        }

        public void GetEmployee()
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee()
                {
                    EGrade = 'A',
                    EName = "Rahul",
                    ENoOfExp = 8,
                    ESalary = 120000
                },
                new Employee()
                {
                    EGrade = 'B',
                    EName = "Shankar",
                    ENoOfExp = 2,
                    ESalary = 30000
                },
                new Employee()
                {
                    EGrade = 'A',
                    EName = "Firoz",
                    ENoOfExp = 3,
                    ESalary = 33000
                },
                new Employee()
                {
                    EGrade = 'D',
                    EName = "Amit",
                    ENoOfExp = 5,
                    ESalary = 70000
                },
                new Employee()
                {
                    EGrade = 'E',
                    EName = "Rajesh",
                    ENoOfExp = 4,
                    ESalary = 50000

                },
                new Employee()
                {
                    EGrade = 'A',
                    EName = "Prem",
                    ENoOfExp = 12,
                    ESalary = 220000
                }
            };

            var employeesPromotedByGrade = GetPromotionList(employees, PromoteByGrade);
            Console.WriteLine("Employess Promoted by Grade A are follows");
            PrintEmpDetails(employeesPromotedByGrade);

            var employeesPromotedByExp = GetPromotionList(employees, PromoteByExp);
            Console.WriteLine("Employess Promoted by less Experience are follows");
            PrintEmpDetails(employeesPromotedByExp);
        }

        public bool PromoteByGrade(Employee emp)
        {
            if (emp.EGrade == 'A')
                return true;
            return false;
        }

        public bool PromoteByExp(Employee emp)
        {
            if (emp.ENoOfExp < 5)
                return true;
            return false;
        }

        public void PrintEmpDetails(IEnumerable<Employee> employees)
        {
            Console.WriteLine("***************************************");
            foreach (var emp in employees)
            {
                Console.WriteLine($"Employee Name: {emp.EName}");
                Console.WriteLine($"Employee Grade: {emp.EGrade}");
                Console.WriteLine($"Employee Salary: {emp.ESalary}");
                Console.WriteLine($"Employee Experience: {emp.ENoOfExp}");
                Console.WriteLine("---------------------------------------");

            }
            Console.WriteLine("***************************************");
        }
    }
}
