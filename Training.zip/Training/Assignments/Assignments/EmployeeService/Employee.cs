﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments.EmployeeService
{
    public class Employee
    {
        public string EName { get; set; }
        public double ESalary { get; set; }
        public int ENoOfExp { get; set; }
        public char EGrade { get; set; }
    }
}
