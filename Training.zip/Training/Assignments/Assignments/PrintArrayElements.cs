﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class PrintArrayElements
    {
        public void PrintArrayElement()
        {
            
            int[] arr = { 1, 'A', 2, 'B', 3, 'C' };
            foreach (var number in arr)
            {
                if (number == 65)
                {
                    Console.WriteLine(Encoding.ASCII.GetString(new byte[] { 65 }));
                }
                else if (number == 66)
                {
                    Console.WriteLine(Encoding.ASCII.GetString(new byte[] { 66 }));
                }
                else if (number == 67)
                {
                    Console.WriteLine(Encoding.ASCII.GetString(new byte[] { 67 }));
                }
                else
                {
                    Console.WriteLine(number);
                }

            }

        }
    }
}
