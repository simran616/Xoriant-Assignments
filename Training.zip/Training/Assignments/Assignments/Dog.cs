﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public class Dog : Animal
    {
        public Dog()
        {
            Console.WriteLine("Dog Constructor");
        }

        public override void Eat()
        {
            Console.WriteLine("Dog eats non veg");
        }
        public override void Sound()
        {
            Console.WriteLine("Dog barks-bhoww..");
        }

    }
}
