﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemo2
    {
        public void Main()
        {
            Task task1 = new Task(DrawRoad);
            task1.Start();
            Task task2 = new Task(DrawTree);
            task2.Start();
            Console.WriteLine("End of Main");
        }

        public void DrawRoad()
        {
            Console.WriteLine("DrawRoad is called");
            Thread.Sleep(100);
        }

        public void DrawTree()
        {
            Console.WriteLine("DrawTree is called");
            Thread.Sleep(100);
        }
    }
}
