﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class ParamsDemo
    {
      
        public void ParamsSum()
        {
            int sum = 0;
            sum = GetSum(10,20,30);
            Console.WriteLine("Sum=" + sum);
            sum = GetSum(12,24,36,48,60);
            Console.WriteLine("Sum=" + sum);
            sum = GetSum(50,100);
            Console.WriteLine("Sum=" + sum);
        }
        
        public int GetSum(params int[] nos)
        {
            int sum = 0;
            sum += sum;
            for (int i = 0; i < nos.Length; ++i)
            {
                sum += nos[i];
            }
            return sum;

        }
    }
}
