﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class AmountCalculation
    {
        public void DiscountedAmountCalculation()
        {
            float totalAmount;
            Console.Write("Enter the amount: ");
            float amount = Convert.ToInt32(Console.ReadLine());

            totalAmount=CalculateAmount(amount);
            Console.WriteLine("Discounted Amount: {0}", totalAmount);
        }
        public static float CalculateAmount(float amount)
        {
            int discount = 0;
            float totalAmount = 0;
            DayOfWeek day = DateTime.Now.DayOfWeek;
            Console.WriteLine("Day: {0}",day);

            switch (day)
            {
                case DayOfWeek.Sunday:
                    discount = 5;
                    break;
                case DayOfWeek.Monday:
                    discount =2;
                    break;
                case DayOfWeek.Tuesday:
                    discount = 3;
                    break;
                case DayOfWeek.Wednesday:
                    discount = 3;
                    break;
                case DayOfWeek.Thursday:
                    discount = 5;
                    break;
                case DayOfWeek.Friday:
                    discount = 7;
                    break;
                case DayOfWeek.Saturday:
                    discount = 7;
                    break;
                default:
                    discount = 0;
                    break;

            }
           
            totalAmount = amount - ( amount * discount / 100) ;
            Console.WriteLine("Discount: {0}%",discount);
            return totalAmount;
        }

    }
}
