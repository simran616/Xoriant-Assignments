﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignments
{
    public class TaskDemo5
    {
        public void Main()
        {
            try
            {
                var cancellationSource1 = new CancellationTokenSource();
                var cancellationSource2 = new CancellationTokenSource();
                var cancellationSource3 = new CancellationTokenSource();


                Console.WriteLine("Main Started");
                var task1 = Task.Factory.StartNew(() => Test(1, 2000, cancellationSource1.Token)).ContinueWith((prevTask) => GenerateReport(1, 1000, cancellationSource1.Token));
                var task2 = Task.Factory.StartNew(() => Test(2, 5000, cancellationSource2.Token)).ContinueWith((prevTask) => GenerateReport(2, 2000, cancellationSource2.Token));
                var task3 = Task.Factory.StartNew(() => Test(3, 1000, cancellationSource3.Token)).ContinueWith((prevTask) => GenerateReport(3, 500, cancellationSource3.Token));

                cancellationSource1.Cancel();
                cancellationSource3.Cancel();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("End of Main");
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }

        private void GenerateReport(int taskNo, int sleepTime, CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                Console.WriteLine($"GenerateReport {taskNo} was cancelled");
                token.ThrowIfCancellationRequested();
            }
            Console.WriteLine($"GenerateReport {taskNo} started");
            Thread.Sleep(sleepTime);
            Console.WriteLine($"GenerateReport {taskNo} completed");

        }

        private void Test(int taskNo, int sleepTime, CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                Console.WriteLine($"Test {taskNo} was cancelled");
                token.ThrowIfCancellationRequested();
            }
            Console.WriteLine($"Test {taskNo} started");
            Thread.Sleep(sleepTime);
            Console.WriteLine($"Test {taskNo} completed");
        }
    }
}
