﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public class Cat : Animal
    {
        public Cat()
        {
            Console.WriteLine("Cat Constructor");
        }

        public override void Eat()
        {
            Console.WriteLine("Cat drinks milk");
        }
        public override void Sound()
        {
            Console.WriteLine("Cat says-Meoww...");
        }
    }
}
