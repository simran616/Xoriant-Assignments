﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    public abstract class Animal : IAnimal
    {
        public Animal()
        {
            Console.WriteLine("Animal Constructor called");
        }

        public virtual void Eat()
        {
            Console.WriteLine("Animal Eats");
        }

        public virtual void Sound()
        {
            Console.WriteLine("Animal Sound");
        }

        public void Play()
        {
            Console.WriteLine("Animal Plays");
        }

    }
}
