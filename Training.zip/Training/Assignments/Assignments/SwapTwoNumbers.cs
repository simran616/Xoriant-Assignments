﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class SwapTwoNumbers
    {
        public void main()
        {
            int num1, num2;

            GetNumbersToSwap(out num1, out num2);
            SwapNumbers(ref num1, ref num2);
            Console.WriteLine("Swapped numbers are Number1:{0}\t Number2:{1}", num1, num2);

        }

        static void GetNumbersToSwap(out int num1, out int num2)
        {
            Console.Write("Number1: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Number2: ");
            num2 = Convert.ToInt32(Console.ReadLine());

        }

        static void SwapNumbers(ref int num1, ref int num2)
        {
            int swapTemp = num1;
            num1 = num2;
            num2 = swapTemp;
        }

    }

}
   