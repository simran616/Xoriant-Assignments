﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class Pattern2
    {
        public void DisplayPattern2()
        {

            for (int i = 5; i>=1; i--)
            {
                for (int j=1; j<=5; j++)
                {
                    if (j<=i-1)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.Write("\n");
            }
        }
    }
}
