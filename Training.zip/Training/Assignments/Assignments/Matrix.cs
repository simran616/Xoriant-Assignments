﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class Matrix
    {
        public void PrintMatrixElement()
        {
            int[,] arr = {  {1,2,3},
                            {4,5,6},
                            {7,8,9}
                         };

            Console.Write("Matrix First Row Elements: ");
            for (int column = 0; column <= arr.Rank; column++)
            {
                Console.Write("{0} ", arr[0, column]);
            }

            Console.Write("\nMatrix Last Row Elements: ");
            for (int column = 0; column <= arr.Rank; column++)
            {
                Console.Write("{0} ", arr[(arr.Rank), column]);
            }

            Console.Write("\nMatrix First Column Elements: ");
            for (int rows = 0; rows <= arr.Rank; rows++)
            {
                Console.Write("{0} ", arr[rows, 0]);
            }

            Console.Write("\nMatrix Last Column Elements: ");
            for (int rows = 0; rows <= arr.Rank; rows++)
            {
                Console.Write("{0} ", arr[rows, (arr.Rank)]);
            }

            Console.Write("\nPrimary Diagonal Elements: ");
            for (int rows = 0; rows <= arr.Rank; rows++)
            {
                Console.Write("{0} ", arr[rows, rows]);
            }

            Console.Write("\nSecondary Diagonal Elements: ");
            for (int rows = 0; rows <= arr.Rank; rows++)
            {
               Console.Write("{0} ", arr[rows, 2-rows]);
            }


        }
    }

}
