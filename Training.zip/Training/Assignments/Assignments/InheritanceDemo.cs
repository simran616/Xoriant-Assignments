﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class InheritanceDemo
    {
        public void Display()
        {
            Console.WriteLine("Parent Class\n");
        }
    }
    class Child : InheritanceDemo
    {
        public void Display()
        {
            Console.WriteLine("Child Class\n");
        }
    }
    class GrandChild : Child
    {
        public void Display()
        {
            //calling the display method of InheritanceDemo class
            Console.WriteLine("Callling base's base class method");
            var parent = base.MemberwiseClone() as InheritanceDemo;
            parent.Display();
            Console.WriteLine("GrandChild Class");
        }
    }
}
