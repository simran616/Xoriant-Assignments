﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments.MessageService
{
    delegate void DelegateMessage(string str);
    class MessageServiceApp
    {
        public void Show()
        {
            IMessage message = new Email();
            DisplayMessage(message.Display, "Hello Buddy!!");
            message = new Sms();
            DisplayMessage(message.Display, "SMS here!!");

        }

        public void DisplayMessage(DelegateMessage delMsg, string str)
        {
            delMsg.Invoke(str);
        }
    }
}
