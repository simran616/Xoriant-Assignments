﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments.MessageService
{
    public class Sms : IMessage
    {
        public void Display(string str)
        {
            Console.WriteLine($"SMS service message: {str}");
        }
    }
}
