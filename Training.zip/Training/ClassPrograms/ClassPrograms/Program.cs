﻿using System;

namespace ClassPrograms
{
    class Program
    {
        static void Main(string[] args)
        {
            //Assignment-Day:5
            EmployeeAddress employeeAddress = new EmployeeAddress();
            employeeAddress.EmployeeAddressDetails();
        }

    }
}
