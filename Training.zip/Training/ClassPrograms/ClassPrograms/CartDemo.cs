﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassPrograms
{
    class CartItem
    {
        public int PId { get; set; }
        public double Price { get; set; }
        public int Qty { get; set; }
    }
    class CartDemo
    {
        public void main()
        {
            CartItem cart1 = new CartItem()
            {
                PId = 1,
                Price = 100,
                Qty = 1
            };
            CartItem cart2 = new CartItem()
            {
                PId = 2,
                Price = 200,
                Qty = 2
            };

            CartItem cart3 = new CartItem()
            {
                PId = 3,
                Price = 300,
                Qty = 3
            };

            CartItem cart4 = new CartItem()
            {
                PId = 4,
                Price = 400,
                Qty = 1
            };
            CartItem cart5 = new CartItem()
            {
                PId = 5,
                Price = 500,
                Qty = 1
            };


        }

    }
    //class CartRepo
    //{
    //    private ObservableCollection<CartItem> items = new ObservableCollection<>;
    //    int cartCnt = 0;
    //    public void AddCart(CartItem cart)
    //    {
    //        items.Add(cart);
    //        items.CollectionChanged += Items_CollectionChanged;

    //    }
    //    public void Items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
    //    {
    //       if(e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
    //        {
    //            cartCnt++;
    //        }
    //        else if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
    //        {
    //            cartCnt--;
    //        }
    //        CalculateCartTotal();

    //    }
    //    private void CalculateCartTotal()
    //    {
    //        double total = 0;
    //        foreach( var item in this.items)
    //        {
    //            total += item.Price * item.Qty;
    //        }
    //    }
    //    public 
    //    //public List<CartItem> GetCartItems()
    //    //{

    //    //}
    //}
}
