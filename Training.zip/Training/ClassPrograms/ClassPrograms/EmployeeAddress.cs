﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassPrograms
{
    class EmployeeAddress
    {
        public void EmployeeAddressDetails()
        {
            //Create Employee
            Employee employee = new Employee();
            employee.EId = 101;
            employee.EmployeeName = "Andrew";

            //Create Address
            Address currentAddress = new Address()
            {
                Building = "Temple Tower",
                Street = "Siruseri",
                City = "Chennai"
            };

            //Add Employee
            //employee.AddAddress(currentAddress);
            currentAddress.Employee = employee;

            //Add Address
            employee.Address = currentAddress;

            DisplayEmployee(employee);
            Console.WriteLine("\n===============================================================\n");
            DisplayAddress(currentAddress);
        }

        private static void DisplayAddress(Address address)
        {
            Console.WriteLine("Displaying Employee info for the address\n\nADDRESS\n==========");
            Console.WriteLine("Building:{0}\t Street:{1}\t City:{2}\n", address.Building, address.Street, address.City);

            Console.WriteLine("EMPLOYEE INFORMATION");
            Console.WriteLine("---------------------");
            Console.WriteLine("ID:{0}\tName:{1}", address.Employee.EId, address.Employee.EmployeeName);

        }

        private static void DisplayEmployee(Employee employee)
        {
            Console.WriteLine("Displaying Address of the given employee\n\nEMPLOYEE DETAILS\n===============");
            Console.WriteLine("ID:{0}\tName:{1}\n", employee.EId, employee.EmployeeName);

            Console.WriteLine("ADDRESS INFORMATION");
            Console.WriteLine("---------------------");
            Console.WriteLine("Building:{0}\t Street:{1}\t City:{2}", employee.Address.Building, employee.Address.Street, employee.Address.City);
        }
    }
}
