﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassPrograms
{
    class Employee
    {
        public int EId { get; set; }
        public string EmployeeName { get; set; }
        public Address Address { get; set; }
        //private List<Address> address = new List<Address>();
        //public void AddAddress(Address address)
        //{
        //    this.address.Add(address);
        //}
        //public IEnumerable<Address> GetAddresses()
        //{
        //    return this.address;
        //}

    }
}
