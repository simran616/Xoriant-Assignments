﻿using BusinessLayer.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShopOnWebApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IProductManager productManager;

        public HomeController(ILogger<HomeController> logger, 
            IProductManager productManager)
        {
            _logger = logger;
            this.productManager = productManager;
        }

        /// <summary>
        /// Method to display products in homepage
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            var products = this.productManager.GetProduct();
            return View(products);
        }

        /// <summary>
        /// Method to display details of particular product
        /// </summary>
        /// <param name="pid"></param>
        /// <returns></returns>
        public IActionResult Details(int pid)
        {
            var product = this.productManager.GetProduct(pid);
            return View(product);
        }

        /// <summary>
        /// Method to search any product
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IActionResult SearchProduct(string search)
        {
            if (search != null)
            {
                var product = this.productManager.SearchProduct(search);
                return View("Index", product);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
