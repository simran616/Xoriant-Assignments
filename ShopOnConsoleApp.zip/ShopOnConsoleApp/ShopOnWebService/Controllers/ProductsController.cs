﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnWebService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductManagerAsync productManagerAsync;
        public ProductsController(IProductManagerAsync productManagerAsync)
        {
            this.productManagerAsync = productManagerAsync;
        }

        #region Service

        //GET: /api/Products
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var products = await productManagerAsync.GetProducts();
                return Ok(products);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                                    "Error retriving products from server.");
            }
        }

        //GET: /api/Products/5
        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var product = await productManagerAsync.GetProduct(id);
                if(product == null)
                {
                    return NotFound();
                }
                return Ok(product);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                                    "Error retriving products from server.");
            }
        }

        //POST: /api/Products
        [HttpPost]
        public async Task<ActionResult<Product>> Create(Product product)
        {
            try
            {
                if(product == null)
                {
                    return BadRequest();
                }
                var result = await this.productManagerAsync.AddProduct(product);
                return CreatedAtAction(nameof(Get), new { id = result.PId }, result);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                                    "Error retriving products from server.");
            }
        }

        //DELETE: /api/Products/112
        [HttpDelete("{id:int}")]
        public async Task<ActionResult<Product>> Delete(int id)
        {
            try
            {
                var product = await productManagerAsync.GetProduct(id);
                if (product == null)
                {
                    return NotFound();
                }
                await productManagerAsync.DeleteProduct(id);
                return Ok();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                                    "Error retriving products from server.");
            }
        }

        //PUT: /api/Products/112
        [HttpPut("{id:int}")]
        public async Task<ActionResult<Product>> Update(int id, Product product)
        {
            try
            {
                if (product == null || product.PId != id)
                {
                    return BadRequest();
                }
                var products = await productManagerAsync.UpdateProduct(id,product);
                return Ok(products);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                                    "Error retriving products from server.");
            }
        }

        //GET: /api/Products/apple
        [HttpGet("{key}")]
        public async Task<IActionResult> SearchProduct(string key)
        {
            try
            {
                var result = await this.productManagerAsync.Search(key);
                if (result.Any())
                {
                    return Ok(result);
                }
                return NotFound();
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status404NotFound, "Error Creating new product");
            }
        }
        #endregion
    }
}
