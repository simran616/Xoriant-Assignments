﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Models
{
    public class OrderItem
    {
        public int Qty { get; set; }
        public double Amount { get; set; }
        public Order Order { get; set; }
        public int OrderId { get; set; }

        public Product Products { get; set; }
        public int Pid { get; set; }

        public string ProductName { get; set; }

        public double GetOrderItemAmount()
        {
            return Qty * Products.Price;
        }
    }
}
