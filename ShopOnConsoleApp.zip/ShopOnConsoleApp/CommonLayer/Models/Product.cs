﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Models
{
    public class Product : IComparable<Product>
    {
        private static int IdCount = 1;

        //public int pId;
        public int PId { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
        public string AvailableStatus { get; set; }
        public string ImageUrl { get; set; }

        public Category Category { get; set; }
        public int CategoryId { get; set; }
        public Company Company { get; set; }
        public int CompanyId { get; set; }
        //Constructor
        public Product()
        {
            PId = IdCount++;
        }

        public Product(string ProductName, double Price, string AvailableStatus, string ImageUrl)
        {
            this.ProductName = ProductName;
            this.Price = Price;
            this.AvailableStatus = AvailableStatus;
            this.ImageUrl = ImageUrl;
        }

        public int CompareTo(Product product)
        {
            if (this.PId > product.PId)
            {
                return 1;
            }
            else if (this.PId < product.PId)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }

    }
    
}
