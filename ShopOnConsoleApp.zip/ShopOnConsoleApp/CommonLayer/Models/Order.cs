﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public string Orderstatus { get; set; }
        public DateTime OrderDate { get; set; }
        public double TotalAmount { get; set; }
        public int CustomerId { get; set; }

        private List<OrderItem> OrderItems = new List<OrderItem>();
        public IEnumerable<OrderItem> GetOrderItems()
        {
            return this.OrderItems;
        }
        public void AddOrderItem(OrderItem item)
        {
            this.OrderItems.Add(item);
        }
        public double GetTotalOrderValue()
        {
            double total = 0;
            foreach(var item in this.OrderItems)
            {
                total += item.GetOrderItemAmount();
            }
            return total;
        }

    }
}
