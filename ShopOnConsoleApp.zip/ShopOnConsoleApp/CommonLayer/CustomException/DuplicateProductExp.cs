﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.CustomException
{
    public class DuplicateProductExp : ApplicationException
    {
        public DuplicateProductExp()
        {

        }
        public DuplicateProductExp(string errMsg) :
            base(errMsg)
        {

        }
    }
}
