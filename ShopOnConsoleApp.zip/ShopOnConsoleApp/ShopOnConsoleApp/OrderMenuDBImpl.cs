﻿using BusinessLayer;
using BusinessLayer.Contract;
using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnConsoleApp
{
    public class OrderMenuDBImpl
    {
        public void MainMenu()
        {
            int choice;
            IOrderManager orderManager = new OrderManager();
            do
            {
                Console.WriteLine("Orders Menu");
                Console.WriteLine("=================");
                Console.WriteLine("1. Place a new Order");
                Console.WriteLine("2. Get Order details of a customer ");
                Console.WriteLine("3. Return to Main Menu");

                Console.Write("\nEnter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Clear();
                    ReadOrderData(orderManager);
                    Console.WriteLine();

                }
                else if (choice == 2)
                {
                    Console.Clear();
                    DisplayOrdersByCustId(orderManager);
                    Console.WriteLine();
                }
                else
                {
                    if(choice != 3)
                    Console.WriteLine("Please enter valid option");
                }
            } while (choice != 3);
        }

        private static void ReadOrderData(IOrderManager orderManager)
        {
            Order order = new Order();
            List<OrderItem> orderitems = new List<OrderItem>();
            
            string option ="Y";
            Console.WriteLine("Enter Customer ID:");
                order.CustomerId = Convert.ToInt32(Console.ReadLine());
                do
                {
                        OrderItem orderItem = new OrderItem();
                        Console.WriteLine("Enter Product ID:");
                        orderItem.Pid = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Quantity:");
                        orderItem.Qty = Convert.ToInt32(Console.ReadLine());

                        //orderitems.Add(orderItem);
                        order.AddOrderItem(orderItem);
                        Console.Write("Do you want to insert more products?(Y/N):");
                        option = Console.ReadLine();
                
                
            } while (option != "N");
            try 
            {
                if (orderManager.AddOrder(order))
                {
                    Console.WriteLine($"Order Placed. Your OrderId is: {order.OrderId}");
                }
                else
                {
                    Console.WriteLine("Sorry, could not place the order. Please try again.");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message) ;
            }


        }

        private void DisplayOrdersByCustId(IOrderManager orderManager)
        {
            Console.WriteLine("Please enter the Customer ID:");
            int custId = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            //var orders = orderManager.GetOrder(custId)
            Console.WriteLine("\tORDER DETAILS OF CUSTOMER ID: {0}\n", custId);

            try
            {
                foreach (var order in orderManager.GetOrder(custId))
                {
                    if (order != null)
                    {
                        
                        Console.WriteLine($"Order ID: {order.OrderId}");
                        Console.WriteLine("=============\n");
                        
                            Console.WriteLine($"Product Name: {order.Products.ProductName}");
                            Console.WriteLine($"Quantity: {order.Qty}\nPrice: Rs{order.Products.Price}");
                            Console.WriteLine($"Amount: Rs{order.Amount}");

                        Console.WriteLine("------------------------------------------");
                        Console.WriteLine($"\t\tTotal Amount: Rs{order.Order.TotalAmount}");
                        Console.WriteLine("------------------------------------------");
                        Console.WriteLine();
                    }

                    else
                    {
                        Console.WriteLine("This Customer have no order. Please place a new order.\n");
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            
        }

    }
}
