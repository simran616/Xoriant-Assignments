﻿using BusinessLayer;
using CommonLayer.Models;
using System;

namespace ShopOnConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            //IProductManager manager = new ProductManager();
            do
            {
                Console.WriteLine("Shop On Main Menu");
                Console.WriteLine("=================");
                Console.WriteLine("1. Product Menu");
                Console.WriteLine("2. Customer Menu");
                Console.WriteLine("3. Order Menu");
                Console.WriteLine("4. Exit");
                Console.Write("\nEnter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Clear();
                    new ProductMenuDBImpl().MainMenu();
                    Console.WriteLine();
                }
                else if (choice == 2)
                {
                    Console.Clear();
                    new CustomerMenuDBImpl().MainMenu();
                    Console.WriteLine();
                }
                else if (choice == 3)
                {
                    Console.Clear();
                    new OrderMenuDBImpl().MainMenu();
                    Console.WriteLine();
                }
                else if (choice == 4)
                {
                    Console.Clear();
                    Console.WriteLine("===========================================");
                    Console.WriteLine("Thankyou for your Time, Have a Good Day :)");
                    Console.WriteLine("===========================================");

                }
                else
                {
                    Console.WriteLine("Please enter valid option");
                }
            } while (choice != 4);
            //new ShopOnMenu().MainMenu();
            
           
        }
    }
}
