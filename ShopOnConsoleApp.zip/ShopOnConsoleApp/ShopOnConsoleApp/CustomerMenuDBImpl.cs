﻿using BusinessLayer;
using BusinessLayer.Contract;
using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnConsoleApp
{
    public class CustomerMenuDBImpl
    {
        public void MainMenu()
        {
            int choice;
            ICustomerManager customerManager = new CustomerManager();
            do
            {
                Console.WriteLine("Customer Menu");
                Console.WriteLine("=================");
                Console.WriteLine("1. Register a new customer ");
                Console.WriteLine("2. Display Customer Profile ");
                Console.WriteLine("3. Return to Main Menu");
                
                Console.Write("\nEnter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

               if (choice == 1)
                {
                    Console.Clear();
                    ReadCustomerData(customerManager);
                    Console.WriteLine();

                }
               else if (choice == 2)
                {
                    Console.Clear();
                    DisplayCustomers(customerManager);
                    Console.WriteLine();
                }
                else
                {
                    if (choice != 3)
                    Console.WriteLine("Please enter valid option");
                }
            } while (choice != 3);
        }


        private static void ReadCustomerData(ICustomerManager customerManager)
        {
            Customer customer = new Customer();

            Console.WriteLine("Enter Customer name:");
            customer.CustomerName = Console.ReadLine();
            Console.WriteLine("Enter 10 digit Mobile no:");
            customer.MobileNo = Console.ReadLine();
            Console.WriteLine("Enter Email Id:");
            customer.EmailId = Console.ReadLine();
            Console.WriteLine("Enter Password:");
            customer.Password = Console.ReadLine();


            try
            {
                var isInserted = customerManager.AddCustomer(customer);
                if (isInserted)
                {
                    Console.WriteLine($"\nCustomer Registered with the above details\n");
                }
                else
                {
                    Console.WriteLine("\nCustomer already exist\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }


        private static void DisplayCustomers(ICustomerManager customerManager)
        {
            Console.WriteLine("Please enter the Customer ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"\nID\tName\tMobileNo\tEmail");
            Console.WriteLine("----------------------------------------------------------");
            var customer = customerManager.GetCustomers(id);
            if (customer != null)
            {
                DisplayCustomerData(customer);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Product not Found\n");
            }
        }

        private static void DisplayCustomerData(Customer customer)
        {

            var result = $"{customer.CustomerId}\t{customer.CustomerName}\t{customer.MobileNo}\t{customer.EmailId}";
            Console.WriteLine(result);
        }


    }
}
