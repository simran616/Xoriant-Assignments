﻿using BusinessLayer;
using BusinessLayer.Util;
using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnConsoleApp
{
    public class ShopOnMenu
    {
        public void MainMenu()
        {
            int choice;
            IProductManager manager = new ProductManager();
            do
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("=================");
                Console.WriteLine("1. Insert Product Details");
                Console.WriteLine("2. Display Product Details");
                Console.WriteLine("3. Search Product by ID");
                Console.WriteLine("4. Update Product");
                Console.WriteLine("5. Delete Product");
                Console.WriteLine("6. Sort Product by ID");
                Console.WriteLine("7. Sort Product by Price");
                Console.WriteLine("8. Sort Product by Name");
                Console.WriteLine("9. Exit");
                Console.Write("Enter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    ReadProductData(manager);
                    Console.WriteLine();
                    string option;
                    do
                    {
                        Console.Write("Do you want to insert more product?(Y/N):");
                        //Console.WriteLine("Press 1 for Yes or 0 to return to the Main Menu");
                        option = Console.ReadLine();
                        if (option == "Y" || option == "y")
                        {
                            ReadProductData(manager);
                        }
                        else
                        {
                            option = "N";
                        }
                    } while (option != "N");
                    

                }
                else if (choice == 2)
                {
                    Console.Clear();
                    DisplayProducts(manager);
                    Console.WriteLine();
                    
                }
                else if (choice == 3)
                {
                    Console.Clear();
                    DisplayProductsbyId(manager);
                    Console.WriteLine();

                }
                else if (choice == 4)
                {
                    Console.Clear();
                    UpdateProductsbyId(manager);
                    Console.WriteLine();
                }
                else if (choice == 5)
                {
                    Console.Clear();
                    DeleteProductsbyId(manager);
                    Console.WriteLine();
                }
                else if (choice == 6)
                {
                    Console.Clear();
                    SortByID(manager);

                }
                else if (choice == 7)
                {
                    Console.Clear();
                    SortByPrice(manager);

                }
                else if (choice == 8)
                {
                    Console.Clear();
                    SortByName(manager);

                }
                else if (choice == 9)
                {
                    Console.Clear();
                    Console.WriteLine("===========================================");
                    Console.WriteLine("Thankyou for your Time, Have a Good Day :)");
                    Console.WriteLine("===========================================");

                }
                else
                {
                    Console.WriteLine("Please enter valid option");
                }
            } while (choice != 9);
        }

        private static void ReadProductData(IProductManager manager)
        {
            Product product = new Product();
            //product.pid = 0;
            //Console.WriteLine("\nEnter Product id:");
            //var isPid = int.TryParse(Console.ReadLine(), out product.pid);
            Console.WriteLine("Enter Product name:");
            product.ProductName = Console.ReadLine();
            Console.WriteLine("Enter Product Price:");
            product.Price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter AvailableStatus: ");
            product.AvailableStatus = Console.ReadLine();
            Console.WriteLine("Enter Image Url: ");
            product.ImageUrl = Console.ReadLine();

            try
            {
                var isInserted = manager.AddProduct(product);
                if (isInserted)
                {
                    Console.WriteLine("\nProduct Inserted\n");
                }
                else
                {
                    Console.WriteLine("\nProduct not inserted\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void DisplayProducts(IProductManager manager)
        {
            Console.WriteLine($"\nID\tName\t Price\t Status\t ImageUrl");
            Console.WriteLine("----------------------------------------------------------");
            foreach (var product in manager.GetProduct())
            {
                 DisplayProductData(product);
            }
        }

        private static void DisplayProductsbyId(IProductManager manager)
        {
            Console.WriteLine("Please enter the product ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"\nID\tName\t\t Price\tStatus\tImageUrl");
            Console.WriteLine("----------------------------------------------------------");
            var product = manager.GetProduct(id);
            if (product != null)
            {
                DisplayProductData(product);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Product not Found\n");
            }

        }

        private static void DisplayProductData(Product product)
        {
           
            var result = $"{product.PId}\t{product.ProductName}\tRs{product.Price}\t {product.AvailableStatus}\t {product.ImageUrl}";
            Console.WriteLine(result);
        }

        private static void DeleteProductsbyId(IProductManager manager)
        {

            Console.WriteLine("Please enter the product ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            var product = manager.GetProduct(id);
            if (product != null)
            {
                var isDeleted = manager.DeleteProduct(id);
                if (isDeleted)
                {
                    Console.WriteLine($"Product with ProductID: {id} is deleted");
                }
            }
            else
            {
                Console.WriteLine("Invalid Product ID\n");
            }

        }

        private static void UpdateProductsbyId(IProductManager manager)
        {
            
            Console.WriteLine("Please enter the product ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            var product = manager.GetProduct(id);
            if (product != null)
            {
                Console.WriteLine("Want to update Product Name (Y/N):");
                string result = Console.ReadLine();
                if (result == "y" || result == "Y")
                {
                    Console.WriteLine("Enter Product Name :");
                    product.ProductName = Console.ReadLine();
                }
                Console.WriteLine("Want to update Product Price (Y/N):");
                string result1 = Console.ReadLine();
                if (result1 == "y" || result1 == "Y")
                {
                    Console.WriteLine("Enter Product Price :");
                    product.Price = Convert.ToDouble(Console.ReadLine());
                }
                Console.WriteLine("Want to update Product Available Status (y/n):");
                string result2 = Console.ReadLine();
                if (result2 == "y" || result2 == "Y")
                {
                    Console.WriteLine("Enter Available Status :");
                    product.AvailableStatus = Console.ReadLine();
                }
                Console.WriteLine("Want to update Product Image URL (y/n):");
                string result3 = Console.ReadLine();
                if (result3 == "y" || result3 == "Y")
                {
                    Console.WriteLine("Enter ImageUrl :");
                    product.ImageUrl = Console.ReadLine();
                }
                var isUpdated = manager.UpdateProduct(product);
                if (isUpdated)
                {
                    Console.WriteLine("Product updated");
                }
                
            }
            else
            {
                Console.WriteLine("Invalid Product ID");
            }


        }
        private static void SortByID(IProductManager manager)
        {
            var products = manager.SortById();
            Console.WriteLine($"\nID\tName\t Price\t Status\t ImageUrl");
            Console.WriteLine("----------------------------------------------------------");
            foreach (var items in products)
            {
                DisplayProductData(items);
            }
        }

        private static void SortByPrice(IProductManager manager)
        {
            var products = manager.SortByPrice();
            Console.WriteLine($"\nID\tName\t Price\t Status\t ImageUrl");
            Console.WriteLine("----------------------------------------------------------");
            foreach (var items in products)
            {
                DisplayProductData(items);
            }
        }
        private static void SortByName(IProductManager manager)
        {
            var products = manager.SortByName();
            Console.WriteLine($"\nID\tName\t Price\t Status\t ImageUrl");
            Console.WriteLine("----------------------------------------------------------");
            foreach (var items in products)
            {
                DisplayProductData(items);
            }
        }
    }
}
