﻿using BusinessLayer;
using BusinessLayer.Contract;
using BusinessLayer.Util;
using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnConsoleApp
{
    public class ProductMenuDBImpl
    {
        public void MainMenu()
        {
            int choice;
            IProductManager productManager = new ProductManager();
            ICompanyManager companyManager = new CompanyManager();
            do
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("=================");
                Console.WriteLine("1. Display Product Details");
                Console.WriteLine("2. Insert a new Product");
                Console.WriteLine("3. Search Product by ID");
                Console.WriteLine("4. Update Product");
                Console.WriteLine("5. Delete Product");
                Console.WriteLine("6. Get Company Details");
                Console.WriteLine("7. Search a Product");
                //Console.WriteLine("8. Sort Product by Name");
                Console.WriteLine("8. Return to Main Menu");
                Console.Write("\nEnter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Clear();
                    DisplayProducts(productManager);
                    Console.WriteLine();

                }
                else if (choice == 2)
                {
                    Console.Clear();
                    ReadProductData(productManager);
                    Console.WriteLine();

                }
                else if (choice == 3)
                {
                    Console.Clear();
                    DisplayProductsbyId(productManager);
                    Console.WriteLine();

                }
                else if (choice == 4)
                {
                    Console.Clear();
                    UpdateProduct(productManager);
                    Console.WriteLine();

                }
                else if (choice == 5)
                {
                    Console.Clear();
                    DeleteProductsbyId(productManager);
                    Console.WriteLine();

                }
                else if (choice == 6)
                {
                    Console.Clear();
                    DisplayCompanyDetails(companyManager);
                    Console.WriteLine();

                }
                else if (choice == 7)
                {
                    Console.Clear();
                    SearchProduct(productManager);
                    Console.WriteLine();

                }
                else
                {
                    if(choice !=9)
                    Console.WriteLine("Please enter valid option");
                }
            } while (choice != 8);
        }

        private void SearchProduct(IProductManager productManager)
        {
            Console.WriteLine("What do you wanna search? ");
            var search = Console.ReadLine();
            Console.WriteLine("\t PRODUCT DETAILS");
            Console.WriteLine("======================================");
            foreach (var product in productManager.SearchProduct(search))
            {
                Console.WriteLine($"{product.ProductName}\t Price: Rs{product.Price}\n");
            }
        }

        private void DisplayCompanyDetails(ICompanyManager companyManager)
        {
            Console.WriteLine("Company ID\tCompany Name");
            Console.WriteLine("------------------------------");
            foreach (var company in companyManager.GetCompanies())
            {
                Console.WriteLine($" {company.CompanyId}\t\t{company.CompanyName}");
            }
        }

        private void UpdateProduct(IProductManager productManager)
        {
            Console.WriteLine("Please enter the product ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            var product = productManager.GetProduct(id);
            if (product != null)
            {
                Console.WriteLine("Want to update Product Name (Y/N):");
                string result = Console.ReadLine();
                if (result == "y" || result == "Y")
                {
                    Console.WriteLine("Enter Product Name :");
                    product.ProductName = Console.ReadLine();
                }
                Console.WriteLine("Want to update Product Price (Y/N):");
                string result1 = Console.ReadLine();
                if (result1 == "y" || result1 == "Y")
                {
                    Console.WriteLine("Enter Product Price :");
                    product.Price = Convert.ToDouble(Console.ReadLine());
                }
                Console.WriteLine("Want to update Product Available Status (y/n):");
                string result2 = Console.ReadLine();
                if (result2 == "y" || result2 == "Y")
                {
                    Console.WriteLine("Enter Available Status :");
                    product.AvailableStatus = Console.ReadLine();
                }
                
                productManager.UpdateProduct(product);
                Console.WriteLine("Product updated");
            }
            else
            {
                Console.WriteLine("Invalid Product ID");
            }
        }

        private void DeleteProductsbyId(IProductManager productManager)
        {
            Console.WriteLine("Enter the product id: ");
            int pId = Convert.ToInt32(Console.ReadLine());
            try
            {
                var isDeleted = productManager.DeleteProduct(pId);
                if (isDeleted)
                {
                    Console.WriteLine($"\nProduct Deleted.\n");
                }
                else
                {
                    Console.WriteLine("\nProduct not Deleted.\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ReadProductData(IProductManager productManager)
        {
            Product product = new Product();

            Console.WriteLine("Enter Product name:");
            product.ProductName = Console.ReadLine();
            Console.WriteLine("Enter Price:");
            product.Price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Company Id:");
            product.CompanyId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Category Id:");
            product.CategoryId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Available Status:");
            product.AvailableStatus = Console.ReadLine();
            Console.WriteLine("Enter Image URL:");
            product.ImageUrl = Console.ReadLine();


            try
            {
                var isInserted = productManager.AddProduct(product);
                if (isInserted)
                {
                    Console.WriteLine($"\nProduct Inserted.\n");
                }
                else
                {
                    Console.WriteLine("\nProduct not Inserted.\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        private static void DisplayProducts(IProductManager productManager)
        {
            Console.WriteLine($"\nID\tName\t\tPrice\t CompanyID\tCategoryID\tStatus\t ImageUrl");
            Console.WriteLine("--------------------------------------------------------------------------------------");
            foreach (var product in productManager.GetProduct())
            {
                DisplayProductData(product);
            }
        }
        private static void DisplayProductsbyId(IProductManager productManager)
        {
            Console.WriteLine("Please enter the product ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"\nID\tName\t\tPrice\t CompanyID\tCategoryID\tStatus\t ImageUrl");
            Console.WriteLine("--------------------------------------------------------------------------------------");
            var product = productManager.GetProduct(id);
            if (product != null)
            {
                DisplayProductData(product);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Product not Found\n");
            }

        }

        private static void DisplayProductData(Product product)
        {

            var result = $"{product.PId}\t{product.ProductName}\t Rs{product.Price}\t{product.CompanyId}\t {product.CategoryId}\t\t{product.AvailableStatus}\t{product.ImageUrl}";
            Console.WriteLine(result);
        }


        
    }
}
