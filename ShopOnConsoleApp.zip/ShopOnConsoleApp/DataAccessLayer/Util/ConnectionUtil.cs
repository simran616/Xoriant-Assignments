﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Util
{
    public class ConnectionUtil
    {
        //private string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";
        private string connectionString = string.Empty;
        private static ConnectionUtil connectionUtil = new ConnectionUtil();
        private ConnectionUtil()
        {
            var builder = new ConfigurationBuilder()
                                .SetBasePath(Directory.GetCurrentDirectory())
                                .AddJsonFile("appsettings.json");
            IConfiguration configuration = builder.Build();
            connectionString = configuration.GetConnectionString("Default");
        }
        public static ConnectionUtil GetInstance()
        {
            return connectionUtil;
        }
        public string GetConnectionString()
        {
            //string connectionString = string.Empty;
            return this.connectionString;
        }
    }
}
