﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Contact
{
    public interface IOrderRepository
    {
        public bool InsertOrder(Order order);
        public IEnumerable<Order> GetOrder();
        public IEnumerable<OrderItem> GetOrder(int customerId, bool isEagerLoad = false);

        public bool UpdateOrder(Order order);

        public bool DeleteOrder(int orderiId);
        public Order GetOrderbyId(int orderId);
    }
}

