﻿using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBImpl
{
    public class ProductRepositoryDBImpl : IProductRepository
    {
        //string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";
        private readonly string connectionString = string.Empty;
        //private IEnumerable<Product> products = null;
        public ProductRepositoryDBImpl()
        {
            ConnectionUtil util = ConnectionUtil.GetInstance();
            this.connectionString = util.GetConnectionString();
            //this.products = new
        }
        /// <summary>
        /// To delete product v=by ProductID
        /// </summary>
        /// <param name="pId"></param>
        /// <returns></returns>
        public bool DeleteProduct(int pId)
        {
            bool isDeleted = false;
            string sqlSt = @"UPDATE dbo.product
                            SET isDeleted = 1
                            WHERE pid = " + pId + ";";
            
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    //SqlDataReader reader = command.ExecuteNonQuery();
                    int noOfRecords = command.ExecuteNonQuery();
                    if (noOfRecords > 0)
                    {
                        isDeleted = true;
                    }
                   
                }
            }
            catch (Exception)
            {

                throw;
            }

            return isDeleted;
        }

        /// <summary>
        /// To get PRoducts from Product table
        /// </summary>
        /// <returns>IEnumerable<Product></returns>
        public IEnumerable<Product> GetProduct()
        {
            List<Product> products = new List<Product>();
            //SqlConnection sqlConnection = null;
            string sqlSt = "SP_GetProductInfo";
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt,sqlConnection);
                    //if we are using stotred proc, we have to mention in command.
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Product product = new Product();
                        product.PId = Convert.ToInt32(reader["pid"]);
                        product.ProductName = reader["productName"].ToString();
                        product.Price = Convert.ToInt32(reader["price"]);
                        product.CompanyId = Convert.ToInt32(reader["companyId"]);
                        product.CategoryId = Convert.ToInt32(reader["categoryId"]);
                        product.AvailableStatus = reader["availablestatus"].ToString();
                        product.ImageUrl = reader["imageUrl"].ToString();

                        products.Add(product);
                    }
                }
                  
                //Console.WriteLine("connected...");
            }
            catch (Exception)
            {

                throw;
            }
           
            return products;
        }

        public Product GetProduct(int id)
        {
            
            string sqlSt = @"SELECT pid,productname,price,companyid,
                            categoryid,availablestatus,imageUrl
                            FROM dbo.product
                            WHERE pid= "+ id +";";
            Product product = null;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        product = new Product();
                        product.PId = Convert.ToInt32(reader["pid"]);
                        product.ProductName = reader["productname"].ToString();
                        product.Price = Convert.ToInt32(reader["price"]);
                        product.CompanyId = Convert.ToInt32(reader["companyid"]);
                        product.CategoryId = Convert.ToInt32(reader["categoryid"]);
                        product.AvailableStatus = reader["availablestatus"].ToString();
                        product.ImageUrl = reader["imageUrl"].ToString();

                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return product;
        }

        /// <summary>
        /// To inser a new Product
        /// </summary>
        /// <param name="product"></param>
        /// <returns>bool</returns>
        public bool InsertProduct(Product product)
        {
            bool isInserted = false;
            List<Product> products = new List<Product>();
            //SqlConnection sqlConnection = null;
            string sqlSt = "SP_InsertProduct";
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@ProductName", product.ProductName);
                    command.Parameters.AddWithValue("@Price", product.Price);
                    command.Parameters.AddWithValue("@CompanyId", product.CompanyId);
                    command.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                    command.Parameters.AddWithValue("@AvailableStatus", product.AvailableStatus);
                    command.Parameters.AddWithValue("@ImageUrl", product.ImageUrl);

                    int noOfRecords = command.ExecuteNonQuery();
                    if(noOfRecords > 0)
                    {
                        isInserted = true;
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
            return isInserted;
        }

        /// <summary>
        /// Search any product
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IEnumerable<Product> SearchProduct(string search)
        {
            string sqlSt = "SP_SearchProdct";
            List<Product> products = new List<Product>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);
                    //if we are using stotred proc, we have to mention in command.
                    command.CommandType = CommandType.StoredProcedure;

                    //passing the parameters to the stored proc
                    SqlParameter searchData = command.Parameters.Add("@Search", SqlDbType.VarChar);
                    searchData.Value = search;
                    searchData.Direction = System.Data.ParameterDirection.Input;

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Product product = new Product();
                        product.ProductName = reader["productName"].ToString();
                        product.Price = Convert.ToInt32(reader["price"]);
                        //product.ImageUrl = reader["imageUrl"].ToString();

                        products.Add(product);
                    }
                }

                //Console.WriteLine("connected...");
            }
            catch (Exception)
            {

                throw;
            }

            return products;
        }

        public bool UpdateProduct(Product product)
        {
            bool isUpdated = false;
            string spName = "SP_UpdateProducts";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(spName, connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PID", product.PId);
                    command.Parameters.AddWithValue("@ProductName", product.ProductName);
                    command.Parameters.AddWithValue("@Price", product.Price);
                    command.Parameters.AddWithValue("@AvailableStatus", product.AvailableStatus);

                    int recordUpdated = command.ExecuteNonQuery();
                    if (recordUpdated > 0)
                    {
                        isUpdated = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
            return isUpdated;
        }
    }
}
