﻿using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBImpl
{
    public class CompanyRepositoryDBImpl : ICompanyRepository
    {
        private readonly string connectionString = string.Empty;
        public CompanyRepositoryDBImpl()
        {
            ConnectionUtil util = ConnectionUtil.GetInstance();
            this.connectionString = util.GetConnectionString();
        }
        public IEnumerable<Company> GetCompanies()
        {
            List<Company> companies = new List<Company>();
            string sqlSt = @"SELECT c.companyid,c.companyname FROM dbo.company c
                            WHERE c.isdeleted=0";
            SqlDataAdapter adapter = null;
            DataSet dataSet = new DataSet();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    adapter = new SqlDataAdapter(sqlSt, connection);
                    adapter.Fill(dataSet, "Company");
                    DataTable table = dataSet.Tables["Company"];
                    foreach (DataRow rows in table.Rows)
                    {
                        Company company = new Company();
                        company.CompanyId = Convert.ToInt32(rows["companyId"]);
                        company.CompanyName = rows["companyName"].ToString();

                        companies.Add(company);

                    }
                }

            }
            catch (Exception)
            {

                throw;
            }
            return companies;

        }
    }
}
