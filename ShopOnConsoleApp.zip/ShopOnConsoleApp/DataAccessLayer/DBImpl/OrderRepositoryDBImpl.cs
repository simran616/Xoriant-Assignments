﻿using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBImpl
{
    public class OrderRepositoryDBImpl : IOrderRepository
    {
        //string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";
        private readonly string connectionString = string.Empty;
        private readonly IProductRepository productRepo = null;
        public OrderRepositoryDBImpl()
        {
            ConnectionUtil util = ConnectionUtil.GetInstance();
            this.connectionString = util.GetConnectionString();

            this.productRepo = new ProductRepositoryDBImpl();
        }
        public bool DeleteOrder(int orderiId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Order> GetOrder()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OrderItem> GetOrder(int customerId,bool isEagerLoad=false)
        {
            List<OrderItem> orders = new List<OrderItem>();
            string sqlSt = "SP_GetOrderDetailsByCustomerId";
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    //passing the parameters to the stored proc
                    SqlParameter custId = command.Parameters.Add("@CustomerId", SqlDbType.Int);
                    custId.Value = customerId;
                    custId.Direction = System.Data.ParameterDirection.Input;

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        OrderItem orderItem = new OrderItem();
                        orderItem.OrderId = Convert.ToInt32(reader["orderid"]);
                        //int oId = Convert.ToInt32(reader["orderid"]);
                        orderItem.ProductName = reader["productname"].ToString();
                        orderItem.Pid = Convert.ToInt32(reader["pid"]);
                        orderItem.Qty = Convert.ToInt32(reader["qty"]);
                        orderItem.Amount = Convert.ToSingle(reader["amount"]);
                        if (isEagerLoad)
                        {
                            orderItem.Order = GetOrderbyId(orderItem.OrderId);
                            orderItem.Products = productRepo.GetProduct(orderItem.Pid);
                        }
                        orders.Add(orderItem);
                    }
                    //while (reader.Read())
                    //{
                    //    Order order = new Order();
                    //    var orderItem = order.GetOrderItems();


                    //}
                }

                //Console.WriteLine("connected...");
            }
            catch (Exception)
            {

                throw;
            }

            return orders;
        }

        /// <summary>
        /// Insert a new order
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public bool InsertOrder(Order order)
        {
            bool isInserted = false;
            string sqlSt = "SP_InsertOrder";

            SqlTransaction transaction = null;
            try
            {
                
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    transaction = sqlConnection.BeginTransaction();
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection, transaction);

                    //passing the parameters to the stored proc
                    SqlParameter orderDate = command.Parameters.Add("@OrderDate", SqlDbType.Date);
                    orderDate.Value = order.OrderDate;
                    orderDate.Direction = System.Data.ParameterDirection.Input;

                    SqlParameter customerId = command.Parameters.Add("@CustomerId", SqlDbType.Int);
                    customerId.Value = order.CustomerId;
                    customerId.Direction = System.Data.ParameterDirection.Input;


                    SqlParameter orderId = command.Parameters.Add("@OrderId", SqlDbType.Int);
                    orderId.Direction = ParameterDirection.Output;

                    command.CommandType = CommandType.StoredProcedure;
                    int noOfRecords = command.ExecuteNonQuery();
                    if (noOfRecords > 0)
                    {
                        var newOrderId = Convert.ToInt32(command.Parameters["@orderId"].Value);
                        order.OrderId = newOrderId;
                        if (InsertOrderItems(order, sqlConnection, transaction))
                        {
                            transaction.Commit();
                            isInserted = true;
                        }
                        
                    }
                    

                }

            }
            catch (Exception)
            {
                transaction.Rollback();
                throw;
            }
            return isInserted;
           
        }

        private bool InsertOrderItems(Order order, SqlConnection sqlConnection, SqlTransaction transaction)
        {
            bool isInserted = false;
            string sqlSt = "SP_InsertOrderItem";
            try
            {
                foreach(var item in order.GetOrderItems())
                {
                    using(SqlCommand command = new SqlCommand(sqlSt,sqlConnection,transaction))
                    {
                        command.CommandText = sqlSt;
                        command.CommandType = CommandType.StoredProcedure;

                        //@OrderId - parameter
                        SqlParameter orderId = command.Parameters.Add("@OrderId", SqlDbType.Int);
                        orderId.Value = order.OrderId;
                        orderId.Direction = ParameterDirection.Input;

                        //@Quantity - parameter
                        SqlParameter qty = command.Parameters.Add("@Quantity", SqlDbType.Int);
                        qty.Value = item.Qty;
                        qty.Direction = ParameterDirection.Input;

                        //@PId - parameter
                        SqlParameter pid = command.Parameters.Add("@Pid", SqlDbType.Int);
                        pid.Value = item.Pid;
                        pid.Direction = ParameterDirection.Input;

                        if (command.ExecuteNonQuery() <= 0)
                        {
                            isInserted = false;
                            return false;
                        }
                        isInserted = true;
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
            return isInserted;
        }

        public bool UpdateOrder(Order order)
        {
            throw new NotImplementedException();
        }

        public Order GetOrderbyId(int orderId)
        {
            string sqlSt = @"select orderdate,totalAmount from dbo.orderd
                            where orderid= " + orderId + ";";
            Order order = null;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Read the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        order = new Order();
                        order.OrderDate =Convert.ToDateTime( reader["orderdate"]);
                        order.TotalAmount = Convert.ToDouble(reader["totalAmount"]);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return order;
        }
    }
}
