﻿using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBImpl
{
    public class CustomerRepositoryDBImpl : ICustomerRepository
    {
        //string connectionString = @"Data Source=XOR-BSA-224\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";

        private readonly string connectionString = string.Empty;
        public CustomerRepositoryDBImpl()
        {
            ConnectionUtil util = ConnectionUtil.GetInstance();
            this.connectionString = util.GetConnectionString();
        }
        public Customer GetCustomers(int id)
        {
                List<Customer> customers = new List<Customer>();
                //SqlConnection sqlConnection = null;
                string sqlSt = "SP_GetCustomersById";
                Customer customer = null;
                try
                {
                    using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                    {
                        sqlConnection.Open();

                        //Read the data
                        SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                        //if we are using stotred proc, we have to mention in command.text
                        command.CommandType = CommandType.StoredProcedure;

                        //passing the parameters to the stored proc
                        SqlParameter customerId = command.Parameters.Add("@customerid", SqlDbType.NVarChar);
                        customerId.Value = id;

                         SqlDataReader reader = command.ExecuteReader();
                        
                        while (reader.Read())
                        {
                            customer = new Customer();
                            customer.CustomerId = Convert.ToInt32(reader["customerid"]);
                            customer.CustomerName = reader["customername"].ToString();
                            customer.MobileNo = reader["mobileno"].ToString();
                            customer.EmailId = reader["emailid"].ToString();
                           
                            //customers.Add(customer);
                        }
                    }
                }
                catch (Exception)
                {

                    throw;
                }

                return customer;
        
        }

        public bool InsertCustomer(Customer customer)
        {
            bool isInserted = false;
           
            try
            {
                string sqlSt = "SP_InsertCustomer";
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    //Insert the data
                    SqlCommand command = new SqlCommand(sqlSt, sqlConnection);

                    //passing the parameters to the stored proc
                    SqlParameter customerName = command.Parameters.Add("@customername", SqlDbType.NVarChar);
                    customerName.Value = customer.CustomerName;

                    SqlParameter mobileNo = command.Parameters.Add("@MobileNo", SqlDbType.NVarChar);
                    mobileNo.Value = customer.MobileNo;

                    SqlParameter emailId = command.Parameters.Add("@EmailId", SqlDbType.NVarChar);
                    emailId.Value = customer.EmailId;

                    SqlParameter password = command.Parameters.Add("@Password", SqlDbType.NVarChar);
                    password.Value = customer.Password;

                    SqlParameter customerId = command.Parameters.Add("@CustomerId", SqlDbType.Int);
                    customerId.Direction = ParameterDirection.Output;

                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    customer.CustomerId = Convert.ToInt32(command.Parameters["@CustomerId"].Value);
                    isInserted = true;

                }

            }
            catch (Exception)
            {
                throw;
            }
            return isInserted;
        }
    }
}
