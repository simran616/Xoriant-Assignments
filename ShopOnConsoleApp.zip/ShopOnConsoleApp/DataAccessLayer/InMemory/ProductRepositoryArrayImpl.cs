﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.InMemory
{
    public class ProductRepositoryArrayImpl
    {
        private Product[] products;
        private int index = -1;

        //constructor
        public ProductRepositoryArrayImpl()
        {
            this.products = new Product[1];
        }
        
        //add a new product
        public bool InsertProduct(Product product)
        {

            bool isInserted = false;
            //1.check if the array is filled
            if (index == this.products.Length - 1)
            {
                //2. check temp array of the products size
                var temp = new Product[this.products.Length];

                //3.Copy data from products to temp
                Array.Copy(this.products, temp, this.products.Length);

                //4.Extend Products
                this.products = new Product[this.products.Length * 2];

                //5.Copy data from temp to products
                Array.Copy(temp, this.products, temp.Length);
            }

            index++;
            this.products[index] = product;
            isInserted = true;

            return isInserted;
        }

        public Product[] GetProduct()
        {
            Product[] temp = new Product[index+1];
            Array.Copy(this.products, temp, index+1);
            return temp;
        }

        public Product GetProduct(int id)
        {
            var products = GetProduct();
            Product productTemp = null;
            foreach(var product in products)
            {
                if (product.PId == id)
                {
                    return productTemp = product;
                }
            }
            return productTemp;
        }
        
    }
}
