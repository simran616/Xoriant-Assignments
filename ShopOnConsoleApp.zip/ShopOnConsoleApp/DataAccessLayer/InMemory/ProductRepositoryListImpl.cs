﻿using CommonLayer.Models;
using CommonLayer.CustomException;
using DataAccessLayer.Contact;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.InMemory
{
    public class ProductRepositoryListImpl : IProductRepository
    {
        private List<Product> products;
        public ProductRepositoryListImpl()
        {
            this.products = new List<Product>();
        }

        //method to insert product
        public bool InsertProduct(Product product)
        {
            bool result = false;
            bool isInserted = false;
            var existingProduct = this.products.FirstOrDefault(x => x.PId == product.PId);
            //if(existingProduct == null)
            //{
            //    this.products.Add(product);
            //    isInserted = false;
            //}
            foreach (var product1 in products)
            {
                result = string.Equals(product1.ProductName, product.ProductName, StringComparison.OrdinalIgnoreCase);
            }
            if (result == false)
            {
                this.products.Add(product);
                isInserted = true;
            }
            else
            {
                throw new DuplicateProductExp($"Product of name {product.ProductName} already exist");
            }
            return isInserted;
        }

        //method to get all products
        public IEnumerable<Product> GetProduct()
        {
            return this.products;
        }

        //get products by id
        public Product GetProduct(int id)
        {
            return this.products.FirstOrDefault(x => x.PId == id);
        }

        //delete a product by id
        public bool DeleteProduct(int id)
        {
            bool isDeleted = false;
            var record = this.products.Remove(this.products.FirstOrDefault(x => x.PId == id));
            if(record)
            {
                isDeleted = true;
            }
            return isDeleted;
        }

        //To Update the Product
        public bool UpdateProduct(Product product)
        {
            bool updatedList = false;
            Product productToUpdate = this.products.FirstOrDefault(x => x.PId == product.PId);
            if (productToUpdate != null)
            {
                // productToUpdate.productId = product.productId;
                productToUpdate.ProductName = product.ProductName;
                productToUpdate.Price = product.Price;
                productToUpdate.AvailableStatus = product.AvailableStatus;
                productToUpdate.ImageUrl = product.ImageUrl;
                updatedList = true;
            }
            return updatedList;
        }

        public IEnumerable<Product> SearchProduct(string search)
        {
            throw new NotImplementedException();
        }
    }
}
