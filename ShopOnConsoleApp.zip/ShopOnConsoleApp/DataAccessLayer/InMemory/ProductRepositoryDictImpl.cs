﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.InMemory
{
    public class ProductRepositoryDictImpl
    {
        private Dictionary<int, Product> products = null;
        public ProductRepositoryDictImpl()
        {
            this.products = new Dictionary<int, Product>();
        }
        public bool InsertProduct(Product product)
        {
            bool isInserted = false;
            try
            {
                this.products.Add(product.PId, product);
                isInserted = true;
            }
            catch (Exception)
            {
                //log the exception
                //rethrow the exception to the caller
            }
           
            return isInserted;
        }

        public List<Product> GetProducts()
        {
            List<Product> products = new List<Product>();
            foreach(var product in this.products)
            {
                var newProduct = product.Value;
                products.Add(newProduct);
            }
            return products;
        }

        //get products by id
        

        //delete a product by id
        

        //To Update the Product
        
    }
}
