﻿using CommonLayer.Models;
using DataAccessLayer.Contact;
using EFDataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDataLayer
{
    public class ProductRepositoryAsyncImpl : IProductRepositoryAsync
    {
        private readonly db_shoponContext context;
        public ProductRepositoryAsyncImpl(db_shoponContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// Method to insert a new product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<CommonLayer.Models.Product> AddProduct(CommonLayer.Models.Product product)
        {
            try
            {
                var productDb = new Models.Product()
                {
                    Availablestatus = product.AvailableStatus,
                    Categoryid = product.CategoryId,
                    Companyid = product.CompanyId,
                    ImageUrl = product.ImageUrl,
                    IsDeleted = false,
                    Price = product.Price,
                    Productname = product.ProductName
                };
                var result = await this.context.Products.AddAsync(productDb);
                await context.SaveChangesAsync();
                return new CommonLayer.Models.Product()
                {
                    AvailableStatus = result.Entity.Availablestatus,
                    ProductName = result.Entity.Productname,
                    Price = result.Entity.Price.Value,
                    CompanyId = result.Entity.Companyid.Value,
                    CategoryId = result.Entity.Categoryid.Value,
                    ImageUrl = result.Entity.ImageUrl,
                    PId = result.Entity.Pid
                };
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// method to delete product by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task DeleteProduct(int id)
        {
            var productToDelete = this.context.Products.FirstOrDefaultAsync(x => x.Pid == id);
            if (productToDelete != null)
            {
                this.context.Products.Remove(await productToDelete);
                await this.context.SaveChangesAsync();
            }
        }

        /// <summary>
        /// Method to get product by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<CommonLayer.Models.Product> GetProduct(int id)
        {
            var result = await this.context.Products
                       .Include(p => p.Company)
                       .FirstOrDefaultAsync(p => p.Pid == id);
            if (result != null)
            {
                var company = new CommonLayer.Models.Company()
                {
                    CompanyId = result.Company.Companyid,
                    CompanyName = result.Company.Companyname
                };
                return new CommonLayer.Models.Product()
                {
                    AvailableStatus = result.Availablestatus,
                    ProductName = result.Productname,
                    Price = result.Price.Value,
                    CompanyId = result.Companyid.Value,
                    CategoryId = result.Categoryid.Value,
                    ImageUrl = result.ImageUrl,
                    Company = company

                };

            }
            return null;
        }

        /// <summary>
        /// Method to get all products
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<CommonLayer.Models.Product>> GetProducts()
        {
            var result = await this.context.Products.ToListAsync();
            var resultToReturn = (from p in result
                                  select new CommonLayer.Models.Product
                                  {
                                      AvailableStatus = p.Availablestatus,
                                      ProductName = p.Productname,
                                      Price = p.Price.Value,
                                      CompanyId = p.Companyid.Value,
                                      CategoryId = p.Categoryid.Value,
                                      ImageUrl = p.ImageUrl

                                  }
                                  ).ToList();
            return resultToReturn;
        }

        /// <summary>
        /// Method to search a product
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task<IEnumerable<CommonLayer.Models.Product>> Search(string key)
        {
            IQueryable<Models.Product> query = this.context.Products;
            if (!string.IsNullOrEmpty(key))
            {
                query = query.Where(p => p.Productname.Contains(key));
            }
            var result = await query.ToListAsync();
            var resultToReturn = (from p in result
                                  select new CommonLayer.Models.Product
                                  {
                                      AvailableStatus = p.Availablestatus,
                                      CategoryId = p.Categoryid.Value,
                                      CompanyId = p.Companyid.Value,
                                      ImageUrl = p.ImageUrl,
                                      PId = p.Pid,
                                      Price = p.Price.Value,
                                      ProductName = p.Productname
                                  }).ToList();
            return resultToReturn;

        }

        /// <summary>
        /// Method to update product
        /// </summary>
        /// <param name="id"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<CommonLayer.Models.Product> UpdateProduct(int id, CommonLayer.Models.Product product)
        {
            var productToUpdate= await this.context.Products.FirstOrDefaultAsync(x => x.Pid == id);
            if (productToUpdate != null)
            {
                productToUpdate.Availablestatus = product.AvailableStatus;
                productToUpdate.Categoryid = product.CategoryId;
                productToUpdate.Companyid = product.CompanyId;
                productToUpdate.ImageUrl = product.ImageUrl;
                productToUpdate.Price = product.Price;
                productToUpdate.Productname = product.ProductName;

                await this.context.SaveChangesAsync();
                return product;

            }
            return null;
        }
    }
}
