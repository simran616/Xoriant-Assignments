﻿using CommonLayer.Models;
using DataAccessLayer.Contact;
using EFDataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDataLayer
{
    public class ProductRepositoryEFImpl : IProductRepository
    {
        private db_shoponContext context = null;
        public ProductRepositoryEFImpl()
        {
            this.context = new db_shoponContext();
        }


        public bool DeleteProduct(int pId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get all the products
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CommonLayer.Models.Product> GetProduct()
        {
            //var products = this.context.Products
            //                .Join(this.context.Companies, p => p.Companyid, c => c.Companyid,
            //                (p, c) => new CommonLayer.Models.Product
            //                {
            //                    PId = p.Pid,
            //                    ProductName = p.Productname,
            //                    Price = p.Price.Value,
            //                    AvailableStatus = p.Availablestatus,
            //                    ImageUrl = p.ImageUrl,
            //                    CategoryId = p.Categoryid.Value,
            //                    Company = new CommonLayer.Models.Company()
            //                    {
            //                        CompanyId = c.Companyid
            //                    }
            //                });
            var dataProduct = this.context.Products.ToList();
            //List<CommonLayer.Models.Product> products = new List<CommonLayer.Models.Product>();
            var products = from p in dataProduct
                           select new CommonLayer.Models.Product
                           {
                               PId=p.Pid,
                               ProductName = p.Productname,
                               Price = p.Price.Value,
                               CompanyId = p.Companyid.Value,
                               CategoryId = p.Categoryid.Value,
                               AvailableStatus = p.Availablestatus,
                               ImageUrl = p.ImageUrl
                           };
            return products;
        }

        /// <summary>
        /// Method to get all products
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CommonLayer.Models.Product GetProduct(int id)
        {
            var dataProduct = this.context.Products;
            //List<CommonLayer.Models.Product> products = new List<CommonLayer.Models.Product>();
            var products = (from p in dataProduct
                            where p.Pid == id
                            select new CommonLayer.Models.Product
                            {
                                PId = p.Pid,
                                ProductName = p.Productname,
                                Price = p.Price.Value,
                                CompanyId = p.Companyid.Value,
                                CategoryId = p.Categoryid.Value,
                                AvailableStatus = p.Availablestatus,
                                ImageUrl = p.ImageUrl
                            }).FirstOrDefault<CommonLayer.Models.Product>();
            return products;
            //throw new NotImplementedException();
        }

        /// <summary>
        /// Method to onsert a new product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool InsertProduct(CommonLayer.Models.Product product)
        {
            bool isInserted = false;
            
            try
            {
                var dataProduct = new Models.Product()
                {
                    Productname = product.ProductName,
                    Price = product.Price,
                    Categoryid = product.CategoryId,
                    Companyid = product.CategoryId,
                    Availablestatus = product.AvailableStatus,
                    ImageUrl = product.ImageUrl
                };
                this.context.Products.Add(dataProduct);
                this.context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
            return isInserted;
            
        }

        /// <summary>
        /// Method to search any product
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public IEnumerable<CommonLayer.Models.Product> SearchProduct(string search)
        {
            
            var dataProduct = this.context.Products.ToList();
            if (!string.IsNullOrEmpty(search))
            {
                var products = (from p in dataProduct
                               where p.Productname
                               .Contains(search)
                select new CommonLayer.Models.Product
                {
                    PId = p.Pid,
                    ProductName = p.Productname,
                    Price = p.Price.Value,
                    CompanyId = p.Companyid.Value,
                    CategoryId = p.Categoryid.Value,
                    AvailableStatus = p.Availablestatus,
                    ImageUrl = p.ImageUrl
                });

                return products;
            }
            return null;
        }

        public bool UpdateProduct(CommonLayer.Models.Product product)
        {
            throw new NotImplementedException();
        }
    }
}
