﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.DBImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class CustomerManager : ICustomerManager
    {
        private ICustomerRepository customerRepo = null;
        public CustomerManager()
        {
            this.customerRepo = new CustomerRepositoryDBImpl();
        }

        public bool AddCustomer(Customer customer)
        {
            return this.customerRepo.InsertCustomer(customer);
        }

        public Customer GetCustomers(int id)
        {
            return this.customerRepo.GetCustomers(id);
        }
    }
}
