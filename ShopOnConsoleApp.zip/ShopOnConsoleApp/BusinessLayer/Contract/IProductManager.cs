﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Util
{
    public interface IProductManager
    {
        public bool AddProduct(Product product);
        public IEnumerable<Product> GetProduct();
        public Product GetProduct(int id);
        public bool UpdateProduct(Product product);
        public bool DeleteProduct(int pId);
        public IEnumerable<Product> SortById();
        public IEnumerable<Product> SortByName();

        public IEnumerable<Product> SortByPrice();
        public IEnumerable<Product> SearchProduct(string search);
    }
}
