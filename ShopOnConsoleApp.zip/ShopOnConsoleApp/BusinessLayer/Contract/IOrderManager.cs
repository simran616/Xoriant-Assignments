﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IOrderManager
    {
        public bool AddOrder(Order order);
        public IEnumerable<Order> GetOrder();
        public Order GetOrderbyId(int orderId);
        public IEnumerable<OrderItem> GetOrder(int customerId);
        public bool UpdateOrder(Order order);
        public bool DeleteOrder(int orderId);
        
    }
}
