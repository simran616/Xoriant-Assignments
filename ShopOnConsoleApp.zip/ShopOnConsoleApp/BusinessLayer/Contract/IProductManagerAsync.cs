﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IProductManagerAsync
    {
        /// <summary>
        /// Method to insert a new product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        Task<Product> AddProduct(Product product);

        /// <summary>
        /// Method to get all products
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<Product>> GetProducts();

        /// <summary>
        /// Method to search a product
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        Task<IEnumerable<Product>> Search(string key);

        /// <summary>
        /// Method to get product by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Product> GetProduct(int id);

        /// <summary>
        /// Method to update product
        /// </summary>
        /// <param name="id"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        Task<Product> UpdateProduct(int id, Product product);

        /// <summary>
        /// method to delete product by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task DeleteProduct(int id);
    }
}

