﻿using CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface ICustomerManager
    {
        public bool AddCustomer(Customer customer);
        public Customer GetCustomers(int id);
    }
}
