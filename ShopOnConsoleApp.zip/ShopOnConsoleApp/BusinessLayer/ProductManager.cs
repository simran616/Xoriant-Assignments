﻿using BusinessLayer.Util;
using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.DBImpl;
using DataAccessLayer.InMemory;
using EFDataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class ProductManager : IProductManager
    {
        //private ProductRepositoryArrayImpl productRepo = null;
        //private ProductRepositoryListImpl productRepo = null;
        //private ProductRepositoryDictImpl productRepo = null;
        private IProductRepository productRepo = null;
        public ProductManager(IProductRepository productRepository)
        {
            this.productRepo = productRepository;
            //this.productRepo = new ProductRepositoryArrayImpl();
            //this.productRepo = new ProductRepositoryDictImpl();
            //this.productRepo = new ProductRepositoryListImpl();
            //this.productRepo = new ProductRepositoryDBImpl();
            //this.productRepo = new ProductRepositoryEFImpl();
        }

        public bool AddProduct(Product product)
        {
           return this.productRepo.InsertProduct(product);
        }
        public IEnumerable<Product> GetProduct()
        {
            return this.productRepo.GetProduct();
        }
        public Product GetProduct(int id)
        {
            return this.productRepo.GetProduct(id);
        }

        public bool DeleteProduct(int pId)
        {
           return  this.productRepo.DeleteProduct(pId);
        }
        public bool UpdateProduct(Product product)
        {
            return this.productRepo.UpdateProduct(product);
        }

        public IEnumerable<Product> SortById()
        {
            var products = GetProduct().ToList();
            products.Sort();
            return products;
        }
        public IEnumerable<Product> SortByPrice()
        {
            var products = GetProduct().ToList();
            products.Sort(new PriceComparer());
            return products;
        }
        public IEnumerable<Product> SortByName()
        {
            var products = GetProduct().ToList();
            products.Sort(new NameComparer());
            return products;
        }

        public IEnumerable<Product> SearchProduct(string search)
        {
            return this.productRepo.SearchProduct(search);
        }
    }

}
