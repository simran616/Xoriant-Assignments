﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.DBImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class OrderManager : IOrderManager
    {
        private IOrderRepository orderRepo = null;
        public OrderManager()
        {
            
            this.orderRepo = new OrderRepositoryDBImpl();

        }
        public bool AddOrder(Order order)
        {
            return this.orderRepo.InsertOrder(order);
        }

        public bool DeleteOrder(int orderId)
        {
            return this.orderRepo.DeleteOrder(orderId);
        }

        public IEnumerable<Order> GetOrder()
        {
            return this.orderRepo.GetOrder();
        }

        public IEnumerable<OrderItem> GetOrder(int customerId)
        {
            return this.orderRepo.GetOrder(customerId,true);
        }

        public Order GetOrderbyId(int orderId)
        {
            return this.orderRepo.GetOrderbyId(orderId);
        }

        public bool UpdateOrder(Order order)
        {
            return this.orderRepo.UpdateOrder(order);
        }
    }
}
