﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using DataAccessLayer.Contact;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class ProductManagerAsync : IProductManagerAsync
    {
        private readonly IProductRepositoryAsync productRepositoryAsync;
        public ProductManagerAsync(IProductRepositoryAsync productRepositoryAsync)
        {
            this.productRepositoryAsync = productRepositoryAsync;
        }
        public Task<Product> AddProduct(Product product)
        {
            return this.productRepositoryAsync.AddProduct(product);
        }

        public Task DeleteProduct(int id)
        {
            return this.productRepositoryAsync.DeleteProduct(id);
        }

        public Task<Product> GetProduct(int id)
        {
            return this.productRepositoryAsync.GetProduct(id);
        }

        public Task<IEnumerable<Product>> GetProducts()
        {
            return this.productRepositoryAsync.GetProducts();
        }

        public Task<IEnumerable<Product>> Search(string key)
        {
            return this.productRepositoryAsync.Search(key);
        }

        public Task<Product> UpdateProduct(int id, Product product)
        {
            return this.productRepositoryAsync.UpdateProduct(id, product);
        }
    }
}
