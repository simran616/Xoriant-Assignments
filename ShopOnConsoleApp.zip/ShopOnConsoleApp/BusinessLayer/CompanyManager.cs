﻿using BusinessLayer.Contract;
using CommonLayer.Models;
using DataAccessLayer.Contact;
using DataAccessLayer.DBImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class CompanyManager : ICompanyManager
    {
        private ICompanyRepository companyRepo = null;
        public CompanyManager()
        {
            this.companyRepo = new CompanyRepositoryDBImpl();
        }
        public IEnumerable<Company> GetCompanies()
        {
            return this.companyRepo.GetCompanies();
        }
    }
}
